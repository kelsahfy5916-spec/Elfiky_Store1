import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import { AppProvider } from '@/context/AppContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import QuickViewModal from '@/components/QuickViewModal';
import AiChatWidget from '@/components/AiChatWidget';
import './globals.css';

export const metadata: Metadata = {
  title: 'Elfiky_Store Official | Advanced Luxury Clothes Website',
  description: 'The advanced premium clothes house. Incorporating 100% Giza Egyptian cotton, waterproof cyberpunk outerwear, an AI Fashion Advisor, and verified instant checkouts via Vodafone Cash and InstaPay.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-black text-white antialiased selection:bg-amber-500 selection:text-black font-sans min-h-screen flex flex-col justify-between">
        <AppProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
          <CartDrawer />
          <QuickViewModal />
          <AiChatWidget />
        </AppProvider>
      </body>
    </html>
  );
}
