import React from 'react';
import { getAllVideos } from '@/app/actions';
import VideoCard from '@/components/VideoCard';
import { Sparkles, Film, Play, Award } from 'lucide-react';

export const revalidate = 0;

export default async function ShowcasePage() {
  const videos = await getAllVideos();

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Premium Showcase Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 py-20 px-4 border-b border-zinc-800 text-center relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono uppercase tracking-widest mb-4">
            <Film className="w-4 h-4 animate-pulse" />
            <span>Elfiky_Store Official Production Core</span>
          </div>
          <h1 className="text-4xl sm:text-7xl font-black uppercase tracking-tight">
            Cinematic <span className="font-serif italic text-amber-500 font-normal">Brand</span> Showcase
          </h1>
          <p className="mt-6 text-zinc-400 text-base sm:text-lg max-w-2xl mx-auto font-light leading-relaxed font-sans">
            Witness our unyielding commitment to advanced luxury. Every video card below opens our high-definition immersive player explaining materials, runway fits, and customer testimonials.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        <div className="flex items-center justify-between mb-12 border-b border-zinc-900 pb-6">
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-black uppercase tracking-wide">Master Visual Productions</h2>
          </div>
          <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest">{videos.length} Premium Motion Features</span>
        </div>

        {/* Video Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {videos.map((vid) => (
            <VideoCard key={vid.id} video={vid} />
          ))}
        </div>

      </div>
    </div>
  );
}
