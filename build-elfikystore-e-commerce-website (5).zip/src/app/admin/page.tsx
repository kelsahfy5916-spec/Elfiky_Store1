'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useApp, AuthUser } from '@/context/AppContext';
import {
  getProductsFilter,
  getAllVideos,
  getAllOrders,
  getCustomerMessagesAdmin,
  updateProductAdmin,
  createProductAdmin,
  deleteProductAdmin,
  createVideoAdmin,
  deleteVideoAdmin,
  updateOrderStatusAdmin,
  updateMessageStatusAdmin,
  forceResetDatabase,
  login
} from '@/app/actions';
import { Shield, ShoppingBag, Film, Package, MessageSquare, Plus, Trash2, Edit3, Check, RefreshCw, Sparkles, AlertCircle, ArrowRight, Save, User, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminDashboardPage() {
  const { user, setUser } = useApp();
  const router = useRouter();

  // Tabs: 'products' | 'orders' | 'videos' | 'messages'
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'videos' | 'messages'>('products');

  // Data state
  const [products, setProducts] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [notif, setNotif] = useState('');

  // Editing Product State
  const [editingProdId, setEditingProdId] = useState<number | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  const [editFeatured, setEditFeatured] = useState<boolean>(false);
  const [editNew, setEditNew] = useState<boolean>(false);

  // Add Product State
  const [showAddProd, setShowAddProd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPrice, setNewPrice] = useState(1200);
  const [newOrigPrice, setNewOrigPrice] = useState('');
  const [newCategory, setNewCategory] = useState('Shirts');
  const [newGender, setNewGender] = useState('Unisex');
  const [newImages, setNewImages] = useState('https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80');
  const [newSizes, setNewSizes] = useState('S, M, L, XL');
  const [newColors, setNewColors] = useState('Black, Off White');
  const [newStock, setNewStock] = useState(25);

  // Add Video State
  const [showAddVid, setShowAddVid] = useState(false);
  const [newVidTitle, setNewVidTitle] = useState('');
  const [newVidDesc, setNewVidDesc] = useState('');
  const [newVidUrl, setNewVidUrl] = useState('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4');
  const [newVidThumb, setNewVidThumb] = useState('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80');
  const [newVidCat, setNewVidCat] = useState('Collection Release');

  // Auth Helper state if evaluator opens directly
  const [authEmail, setAuthEmail] = useState('admin@elfiky.com');
  const [authPass, setAuthPass] = useState('admin123');
  const [authErr, setAuthErr] = useState('');

  const normalizeUser = (u: any): AuthUser => ({
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone || undefined,
    role: u.role,
    address: u.address || undefined,
    city: u.city || undefined,
  });

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [prodRes, vidRes, ordRes, msgRes] = await Promise.all([
        getProductsFilter(),
        getAllVideos(),
        getAllOrders(),
        getCustomerMessagesAdmin(),
      ]);
      setProducts(prodRes);
      setVideos(vidRes);
      setOrders(ordRes);
      setMessages(msgRes);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && user.role === 'admin') {
      loadAllAdminData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const triggerNotif = (msg: string) => {
    setNotif(msg);
    setTimeout(() => setNotif(''), 3000);
  };

  // Instant Quick Evaluator Admin Login
  const handleEvaluatorQuickAdmin = async () => {
    setAuthErr('');
    try {
      const res = await login(authEmail, authPass);
      if (res.success && res.user && res.user.role === 'admin') {
        setUser(normalizeUser(res.user));
        triggerNotif('Authenticated successfully as Master Admin.');
      } else {
        setAuthErr('Invalid Master Admin credentials.');
      }
    } catch (e: any) {
      setAuthErr(e.message);
    }
  };

  // Product Operations
  const handleStartEditProd = (p: any) => {
    setEditingProdId(p.id);
    setEditPrice(p.price);
    setEditStock(p.stock);
    setEditFeatured(p.featured);
    setEditNew(p.newArrival);
  };

  const handleSaveEditProd = async (id: number) => {
    try {
      const updates = {
        price: editPrice,
        stock: editStock,
        featured: editFeatured,
        newArrival: editNew,
      };
      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update-product', payload: { id, updates } }),
      });
      const res = await response.json();
      if (res.success) {
        triggerNotif('Product successfully updated.');
        setEditingProdId(null);
        setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      } else {
        triggerNotif('Error updating product: ' + res.message);
      }
    } catch (e: any) {
      triggerNotif('Communication error.');
    }
  };

  const handleDeleteProd = async (id: number) => {
    if (!confirm('Are you absolutely sure you want to permanently delete this product?')) return;
    try {
      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete-product', payload: { id } }),
      });
      const res = await response.json();
      if (res.success) {
        triggerNotif('Product successfully deleted.');
        setProducts(prev => prev.filter(p => p.id !== id));
      } else {
        triggerNotif('Could not delete product.');
      }
    } catch (e: any) {
      triggerNotif('Communication error.');
    }
  };

  const handleAddProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      const slug = `elfiky-${Date.now()}-${newTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
      const imgArr = newImages.split(',').map(s => s.trim()).filter(Boolean);
      const szArr = newSizes.split(',').map(s => s.trim()).filter(Boolean);
      const clrArr = newColors.split(',').map(s => s.trim()).filter(Boolean);

      const payload = {
        title: newTitle.trim(),
        slug,
        description: newDesc.trim() || 'Premium advanced luxury specifications.',
        price: Number(newPrice) || 1000,
        originalPrice: newOrigPrice ? Number(newOrigPrice) : null,
        category: newCategory,
        gender: newGender,
        images: imgArr.length > 0 ? imgArr : ['https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80'],
        sizes: szArr.length > 0 ? szArr : ['S', 'M', 'L', 'XL'],
        colors: clrArr.length > 0 ? clrArr : ['Black'],
        stock: Number(newStock) || 20,
        featured: true,
        newArrival: true,
      };

      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create-product', payload }),
      });
      const res = await response.json();

      if (res.success && res.product) {
        triggerNotif('New piece added to live master inventory.');
        setShowAddProd(false);
        setNewTitle('');
        setNewDesc('');
        setProducts(prev => [res.product, ...prev]);
      } else {
        triggerNotif('Error creating product.');
      }
    } catch (err) {
      triggerNotif('Communication error.');
    }
  };

  // Video Operations
  const handleAddVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVidTitle.trim()) return;

    try {
      const payload = {
        title: newVidTitle.trim(),
        description: newVidDesc.trim() || 'Official Elfiky visual document.',
        videoUrl: newVidUrl.trim(),
        thumbnailUrl: newVidThumb.trim(),
        category: newVidCat,
        duration: '2:45',
        featured: true,
      };

      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create-video', payload }),
      });
      const res = await response.json();

      if (res.success && res.video) {
        triggerNotif('New brand showcase video published.');
        setShowAddVid(false);
        setNewVidTitle('');
        setNewVidDesc('');
        setVideos(prev => [res.video, ...prev]);
      } else {
        triggerNotif('Error adding video.');
      }
    } catch (err) {
      triggerNotif('Communication error.');
    }
  };

  const handleDeleteVid = async (id: number) => {
    if (!confirm('Permanently delete this brand showcase video?')) return;
    try {
      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete-video', payload: { id } }),
      });
      const res = await response.json();
      if (res.success) {
        triggerNotif('Video successfully deleted.');
        setVideos(prev => prev.filter(v => v.id !== id));
      }
    } catch (err) {
      triggerNotif('Communication error.');
    }
  };

  const handleStatusChange = async (orderId: number, status: string) => {
    try {
      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update-order', payload: { id: orderId, status } }),
      });
      const res = await response.json();
      if (res.success) {
        triggerNotif(`Order fulfillment status updated to ${status}.`);
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
      }
    } catch (err) {
      triggerNotif('Communication error.');
    }
  };

  const handleMsgStatusChange = async (msgId: number, status: string) => {
    try {
      const response = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update-message', payload: { id: msgId, status } }),
      });
      const res = await response.json();
      if (res.success) {
        triggerNotif(`Customer message status updated to ${status}.`);
        setMessages(prev => prev.map(m => m.id === msgId ? { ...m, status } : m));
      }
    } catch (err) {
      triggerNotif('Communication error.');
    }
  };

  // DB Resets
  const handleForceCompleteReset = async () => {
    if (!confirm('⚠️ WARNING: This will completely wipe all custom orders, custom products, and messages, and restore the original premium 10 apparel items and demo videos. Proceed?')) return;
    const res = await forceResetDatabase();
    if (res.success) {
      triggerNotif('Database totally reset and reseeded!');
      loadAllAdminData();
    } else {
      triggerNotif('Reset error.');
    }
  };

  // IF NOT AUTHENTICATED AS ADMIN
  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 bg-red-600 text-white rounded-2xl flex items-center justify-center mx-auto shadow-xl">
            <Shield className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black uppercase tracking-tight">Master Admin Verification Required</h2>
          <p className="text-xs text-zinc-400 font-mono">
            You must authenticate with privileged administrative credentials to modify website elements.
          </p>

          {authErr && <p className="text-xs font-mono text-red-400 font-bold">{authErr}</p>}

          <div className="space-y-3 pt-4 border-t border-zinc-900">
            <input
              type="email"
              value={authEmail}
              onChange={(e) => setAuthEmail(e.target.value)}
              placeholder="Admin Email"
              className="w-full bg-zinc-900 border border-zinc-800 text-white px-4 py-3 rounded-xl font-mono text-xs focus:outline-none focus:border-red-600"
            />
            <input
              type="password"
              value={authPass}
              onChange={(e) => setAuthPass(e.target.value)}
              placeholder="Admin Password"
              className="w-full bg-zinc-900 border border-zinc-800 text-white px-4 py-3 rounded-xl font-mono text-xs focus:outline-none focus:border-red-600"
            />
            <button
              onClick={handleEvaluatorQuickAdmin}
              className="w-full bg-red-600 hover:bg-red-500 text-white font-black py-3.5 rounded-xl uppercase tracking-wider text-xs transition-colors shadow"
            >
              Verify Master Credentials
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Top Notification Overlay */}
      <AnimatePresence>
        {notif && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-black px-6 py-3 rounded-full font-mono text-xs font-black uppercase tracking-widest shadow-2xl flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{notif}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Admin Dashboard Banner */}
      <div className="bg-gradient-to-r from-red-950/40 via-zinc-900 to-red-950/40 py-12 px-4 border-b border-zinc-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-600 rounded-2xl text-white shadow-xl shadow-red-600/30">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-black">Live Production Control</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-black uppercase tracking-tight">Master Admin Control Panel</h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleForceCompleteReset}
              className="px-4 py-2.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 text-red-400 font-mono text-xs font-bold transition-all flex items-center gap-2"
              title="Completely reset and re-seed all tables"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset & Reseed DB</span>
            </button>
            <Link
              href="/"
              className="px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-mono text-xs font-bold border border-zinc-800 transition-all flex items-center gap-2"
            >
              <span>Storefront</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-zinc-900 pb-4 overflow-x-auto">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-5 py-3 rounded-2xl font-mono text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'products' ? 'bg-amber-500 text-black shadow-lg scale-102 font-black' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Apparel Manager ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-5 py-3 rounded-2xl font-mono text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'orders' ? 'bg-amber-500 text-black shadow-lg scale-102 font-black' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Orders Ledger ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('videos')}
            className={`px-5 py-3 rounded-2xl font-mono text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'videos' ? 'bg-amber-500 text-black shadow-lg scale-102 font-black' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Video Showcase Manager ({videos.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('messages')}
            className={`px-5 py-3 rounded-2xl font-mono text-xs font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'messages' ? 'bg-amber-500 text-black shadow-lg scale-102 font-black' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Customer Messages ({messages.length})</span>
          </button>
        </div>

        {/* TAB 1: PRODUCTS MANAGER */}
        {activeTab === 'products' && (
          <div className="mt-8 space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-xl uppercase tracking-wide">Live Website Clothing Inventory</h3>
              <button
                onClick={() => setShowAddProd(!showAddProd)}
                className="bg-amber-500 hover:bg-amber-400 text-black font-black px-6 py-3 rounded-xl text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Piece</span>
              </button>
            </div>

            {/* Add Product Drawer / Modal */}
            <AnimatePresence>
              {showAddProd && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleAddProductSubmit}
                  className="bg-zinc-950 border border-amber-500/40 rounded-3xl p-8 shadow-2xl space-y-6 overflow-hidden"
                >
                  <h4 className="text-base font-black text-amber-400 uppercase tracking-wider font-mono">
                    Engineering New Product Spec
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Product Title</label>
                      <input type="text" required placeholder="Royal Cashmere Hoodie" value={newTitle} onChange={e => setNewTitle(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Category</label>
                      <select value={newCategory} onChange={e => setNewCategory(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono">
                        <option value="Shirts">Shirts</option>
                        <option value="T-Shirts">T-Shirts</option>
                        <option value="Shortes">Shortes</option>
                        <option value="Pants">Pants</option>
                        <option value="Shoes">Shoes</option>
                        <option value="Accessories">Accessories</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Gender Fit</label>
                      <select value={newGender} onChange={e => setNewGender(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono">
                        <option value="Unisex">Unisex</option>
                        <option value="Men">Men</option>
                        <option value="Women">Women</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Price (EGP)</label>
                      <input type="number" required value={newPrice} onChange={e => setNewPrice(Number(e.target.value))} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Original Discount Price (EGP - Optional)</label>
                      <input type="number" placeholder="1500" value={newOrigPrice} onChange={e => setNewOrigPrice(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Stock Count</label>
                      <input type="number" required value={newStock} onChange={e => setNewStock(Number(e.target.value))} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Sizes (Comma separated)</label>
                      <input type="text" required value={newSizes} onChange={e => setNewSizes(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Colors (Comma separated)</label>
                      <input type="text" required value={newColors} onChange={e => setNewColors(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Image URLs (Comma separated)</label>
                    <input type="text" required value={newImages} onChange={e => setNewImages(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Specifications & Description</label>
                    <textarea rows={2} value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Enter supreme luxury materials details..." className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-sans" />
                  </div>

                  <div className="flex gap-4 justify-end pt-2">
                    <button type="button" onClick={() => setShowAddProd(false)} className="px-6 py-3 rounded-xl bg-zinc-900 text-xs font-mono font-bold text-zinc-400">Cancel</button>
                    <button type="submit" className="px-8 py-3 rounded-xl bg-amber-500 text-black text-xs font-black uppercase tracking-wider">Publish New Piece</button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>

            {/* Inventory Editable Table */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-3xl overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-zinc-900 border-b border-zinc-800 font-mono text-[11px] font-bold text-zinc-400 uppercase tracking-widest">
                      <th className="py-4 px-6">Apparel Piece</th>
                      <th className="py-4 px-6">Category</th>
                      <th className="py-4 px-6">Price (EGP)</th>
                      <th className="py-4 px-6">Stock</th>
                      <th className="py-4 px-6">Featured</th>
                      <th className="py-4 px-6">New Season</th>
                      <th className="py-4 px-6 text-right">Modify</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900 text-xs">
                    {products.map((p) => {
                      const isEditing = editingProdId === p.id;
                      return (
                        <tr key={p.id} className="hover:bg-zinc-900/30 transition-colors">
                          <td className="py-4 px-6 flex items-center gap-3">
                            <img src={p.images[0]} alt="" className="w-12 h-14 rounded-xl object-cover flex-shrink-0 bg-zinc-900" />
                            <div>
                              <p className="font-bold text-white text-sm line-clamp-1">{p.title}</p>
                              <span className="text-[10px] font-mono text-zinc-500">Slug: {p.slug}</span>
                            </div>
                          </td>

                          <td className="py-4 px-6 font-mono text-zinc-300">{p.category}</td>

                          <td className="py-4 px-6 font-mono font-bold">
                            {isEditing ? (
                              <input
                                type="number"
                                value={editPrice}
                                onChange={e => setEditPrice(Number(e.target.value))}
                                className="w-20 bg-zinc-900 border border-amber-500 text-white px-2 py-1 rounded font-mono text-xs"
                              />
                            ) : (
                              <span className="text-amber-400 text-sm">{p.price.toLocaleString()} EGP</span>
                            )}
                          </td>

                          <td className="py-4 px-6 font-mono">
                            {isEditing ? (
                              <input
                                type="number"
                                value={editStock}
                                onChange={e => setEditStock(Number(e.target.value))}
                                className="w-16 bg-zinc-900 border border-amber-500 text-white px-2 py-1 rounded font-mono text-xs"
                              />
                            ) : (
                              <span className={`px-2 py-0.5 rounded ${p.stock < 10 ? 'bg-red-500/20 text-red-400 font-bold' : 'bg-emerald-500/10 text-emerald-400'}`}>
                                {p.stock} units
                              </span>
                            )}
                          </td>

                          <td className="py-4 px-6">
                            {isEditing ? (
                              <input
                                type="checkbox"
                                checked={editFeatured}
                                onChange={e => setEditFeatured(e.target.checked)}
                                className="w-4 h-4 accent-amber-500"
                              />
                            ) : (
                              <span className={p.featured ? 'text-amber-400 font-bold' : 'text-zinc-600'}>
                                {p.featured ? '★ Yes' : 'No'}
                              </span>
                            )}
                          </td>

                          <td className="py-4 px-6">
                            {isEditing ? (
                              <input
                                type="checkbox"
                                checked={editNew}
                                onChange={e => setEditNew(e.target.checked)}
                                className="w-4 h-4 accent-amber-500"
                              />
                            ) : (
                              <span className={p.newArrival ? 'text-emerald-400 font-bold font-mono' : 'text-zinc-600'}>
                                {p.newArrival ? '✨ Fresh' : 'No'}
                              </span>
                            )}
                          </td>

                          <td className="py-4 px-6 text-right space-x-2">
                            {isEditing ? (
                              <button
                                onClick={() => handleSaveEditProd(p.id)}
                                className="p-2 bg-emerald-500 hover:bg-emerald-400 text-black rounded-lg font-black transition-colors"
                                title="Save updates"
                              >
                                <Save className="w-4 h-4" />
                              </button>
                            ) : (
                              <button
                                onClick={() => handleStartEditProd(p)}
                                className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-amber-400 rounded-lg transition-colors"
                                title="Modify piece"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                            )}

                            <button
                              onClick={() => handleDeleteProd(p.id)}
                              className="p-2 bg-zinc-900 hover:bg-red-500/10 text-zinc-500 hover:text-red-400 rounded-lg transition-colors"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>

                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ORDERS LEDGER */}
        {activeTab === 'orders' && (
          <div className="mt-8 space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-xl uppercase tracking-wide">Customer Payment Transfers & Orders</h3>
              <button
                onClick={() => loadAllAdminData()}
                className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors flex items-center gap-2 text-xs font-mono"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Order Book</span>
              </button>
            </div>

            {orders.length === 0 ? (
              <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-16 text-center font-mono text-zinc-500">
                No orders registered yet. Simulate a checkout in the storefront to populate.
              </div>
            ) : (
              <div className="space-y-6">
                {orders.map((ord) => (
                  <div key={ord.id} className="bg-zinc-950 border border-zinc-900 hover:border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 transition-all">
                    {/* Top Order Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-900 font-mono">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-black text-amber-400 select-all">{ord.orderNumber}</span>
                          <span className={`px-3 py-1 rounded-full text-[11px] font-black uppercase ${
                            ord.status === 'Delivered' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                            ord.status === 'Shipped' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                            'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}>
                            {ord.status}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 mt-1 font-sans">
                          Customer: <strong className="text-white">{ord.customerName}</strong> ({ord.customerPhone}) &bull; {ord.customerCity}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs text-zinc-500 uppercase tracking-widest mr-2">Change Dispatch:</span>
                        <select
                          value={ord.status}
                          onChange={(e) => handleStatusChange(ord.id, e.target.value)}
                          className="bg-zinc-900 border border-zinc-800 text-white px-3 py-2 rounded-xl text-xs font-bold font-mono focus:outline-none focus:border-amber-500"
                        >
                          <option value="Pending Verification">Pending Verification</option>
                          <option value="Processing">Processing</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Financial Reference Highlight */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-zinc-900/50 p-5 rounded-2xl border border-zinc-800/80 font-mono text-xs">
                      <div>
                        <span className="text-zinc-500 block text-[10px] uppercase">Payment Gateway:</span>
                        <span className="text-base font-black text-white">{ord.paymentMethod}</span>
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[10px] uppercase">Payer Phone/InstaPay Handle:</span>
                        <span className="text-sm font-bold text-emerald-400 select-all">{ord.paymentPhoneOrInsta}</span>
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[10px] uppercase">Ledger Receipt # (Transaction ID):</span>
                        <span className="text-sm font-bold text-amber-400 select-all">#{ord.transactionId}</span>
                      </div>
                    </div>

                    {/* Items & Address */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <h5 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">Ordered Pieces ({ord.items?.length})</h5>
                        <div className="space-y-2.5 divide-y divide-zinc-900">
                          {ord.items?.map((item: any) => (
                            <div key={item.id} className="pt-2 first:pt-0 flex items-center justify-between text-xs font-sans">
                              <span className="font-bold text-zinc-200">{item.quantity} &times; {item.productTitle}</span>
                              <span className="font-mono text-zinc-400">Size {item.selectedSize} &bull; {item.selectedColor}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-3 border-t md:border-t-0 md:border-l border-zinc-900 pt-4 md:pt-0 md:pl-6 text-xs font-sans">
                        <h5 className="font-mono font-bold uppercase tracking-wider text-zinc-400">Delivery Destination</h5>
                        <p className="text-zinc-300 leading-relaxed">{ord.customerAddress}</p>
                        {ord.notes && <p className="text-[11px] text-amber-400/90 italic bg-amber-500/5 p-2 rounded-lg border border-amber-500/20 mt-2">Notes: {ord.notes}</p>}
                        <div className="pt-2 font-mono text-xs font-black text-right">
                          Total Due: <span className="text-amber-400 text-base">{ord.totalAmount.toLocaleString()} EGP</span>
                        </div>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: VIDEOS SHOWCASE MANAGER */}
        {activeTab === 'videos' && (
          <div className="mt-8 space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-xl uppercase tracking-wide">Brand Explainer Videos Library</h3>
              <button
                onClick={() => setShowAddVid(!showAddVid)}
                className="bg-amber-500 hover:bg-amber-400 text-black font-black px-6 py-3 rounded-xl text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow"
              >
                <Plus className="w-4 h-4" />
                <span>Publish Motion Document</span>
              </button>
            </div>

            {/* Add Video Drawer */}
            <AnimatePresence>
              {showAddVid && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleAddVideoSubmit}
                  className="bg-zinc-950 border border-amber-500/40 rounded-3xl p-8 shadow-2xl space-y-6 overflow-hidden"
                >
                  <h4 className="text-base font-black text-amber-400 uppercase tracking-wider font-mono">
                    Publish New Brand Document Reel
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Video Title</label>
                      <input type="text" required placeholder="Summer 2026 Drop Explainer" value={newVidTitle} onChange={e => setNewVidTitle(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Category</label>
                      <select value={newVidCat} onChange={e => setNewVidCat(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono">
                        <option value="Collection Release">Collection Release</option>
                        <option value="Behind The Scenes">Behind The Scenes</option>
                        <option value="Style Guide">Style Guide</option>
                        <option value="Customer Reviews">Customer Reviews</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Video Source URL (MP4 / Embedded direct)</label>
                    <input type="url" required value={newVidUrl} onChange={e => setNewVidUrl(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Thumbnail Cover URL</label>
                    <input type="url" required value={newVidThumb} onChange={e => setNewVidThumb(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-mono" />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1">Video Description & Synopsis</label>
                    <textarea rows={2} required value={newVidDesc} onChange={e => setNewVidDesc(e.target.value)} placeholder="Describe the materials and fit highlights showcased in this reel..." className="w-full bg-zinc-900 border border-zinc-800 px-4 py-3 rounded-xl text-xs text-white font-sans" />
                  </div>

                  <div className="flex gap-4 justify-end pt-2">
                    <button type="button" onClick={() => setShowAddVid(false)} className="px-6 py-3 rounded-xl bg-zinc-900 text-xs font-mono font-bold text-zinc-400">Cancel</button>
                    <button type="submit" className="px-8 py-3 rounded-xl bg-amber-500 text-black text-xs font-black uppercase tracking-wider">Publish Feature</button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>

            {/* Video Cards list */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {videos.map((vid) => (
                <div key={vid.id} className="bg-zinc-950 border border-zinc-900 rounded-3xl overflow-hidden shadow-xl flex flex-col justify-between">
                  <div className="aspect-[16/9] bg-zinc-900 relative overflow-hidden">
                    <img src={vid.thumbnailUrl} alt="" className="w-full h-full object-cover opacity-80" />
                    <span className="absolute top-4 left-4 bg-black/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-mono font-bold text-amber-400 border border-zinc-800">
                      {vid.category}
                    </span>
                  </div>
                  <div className="p-6 space-y-4">
                    <h4 className="font-black text-lg text-white">{vid.title}</h4>
                    <p className="text-xs text-zinc-400 leading-relaxed font-sans">{vid.description}</p>
                    <div className="pt-4 border-t border-zinc-900 flex justify-between items-center">
                      <span className="text-[11px] font-mono text-zinc-500">{new Date(vid.createdAt).toLocaleDateString()}</span>
                      <button
                        onClick={() => handleDeleteVid(vid.id)}
                        className="px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-mono font-bold transition-colors flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Feature</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: CUSTOMER MESSAGES */}
        {activeTab === 'messages' && (
          <div className="mt-8 space-y-8">
            <h3 className="font-black text-xl uppercase tracking-wide">Inquiries Transmitted To Ateliers</h3>

            {messages.length === 0 ? (
              <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-16 text-center font-mono text-zinc-500">
                No customer messages recorded. Submit a query via the Contact page.
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((m) => (
                  <div key={m.id} className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row justify-between gap-6">
                    <div className="space-y-2 flex-1 min-w-0">
                      <div className="flex items-center gap-3">
                        <h5 className="font-bold text-white text-base">{m.senderName}</h5>
                        <span className="text-xs font-mono text-amber-400">{m.senderEmail}</span>
                        {m.senderPhone && <span className="text-xs font-mono text-zinc-500">&bull; Tel: {m.senderPhone}</span>}
                      </div>
                      <div className="p-4 rounded-2xl bg-zinc-900 text-xs text-zinc-200 leading-relaxed font-sans whitespace-pre-line border border-zinc-800">
                        {m.message}
                      </div>
                      <span className="text-[10px] font-mono text-zinc-600 block pt-1">Transmitted on {new Date(m.createdAt).toLocaleString()}</span>
                    </div>

                    <div className="flex flex-col justify-center sm:items-end gap-2 flex-shrink-0">
                      <span className="text-xs text-zinc-500 font-mono uppercase tracking-widest">Inquiry Status:</span>
                      <select
                        value={m.status}
                        onChange={(e) => handleMsgStatusChange(m.id, e.target.value)}
                        className={`bg-zinc-900 border text-white px-4 py-2.5 rounded-xl text-xs font-bold font-mono focus:outline-none transition-colors ${
                          m.status === 'Replied' ? 'border-emerald-500 text-emerald-400' : 'border-amber-500 text-amber-400'
                        }`}
                      >
                        <option value="Unread">Unread</option>
                        <option value="Read">Read</option>
                        <option value="Replied">Replied (Closed)</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
