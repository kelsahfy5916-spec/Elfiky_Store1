import { NextResponse } from 'next/server';
import { db } from '@/db';
import { products, videos, orders, customerMessages } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, payload } = body;

    if (action === 'create-product') {
      const [newProduct] = await db.insert(products).values({
        title: payload.title,
        slug: payload.slug,
        description: payload.description || '',
        price: Number(payload.price) || 1000,
        originalPrice: payload.originalPrice ? Number(payload.originalPrice) : null,
        category: payload.category || 'Shirts',
        gender: payload.gender || 'Unisex',
        images: payload.images || ['https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80'],
        sizes: payload.sizes || ['S', 'M', 'L', 'XL'],
        colors: payload.colors || ['Black'],
        stock: Number(payload.stock) || 20,
        featured: payload.featured !== undefined ? payload.featured : true,
        newArrival: payload.newArrival !== undefined ? payload.newArrival : true,
        rating: '4.9',
        reviewCount: 15,
      }).returning();

      return NextResponse.json({ success: true, product: newProduct });
    }

    if (action === 'update-product') {
      const { id, updates } = payload;
      const [updatedProduct] = await db.update(products).set(updates).where(eq(products.id, id)).returning();
      return NextResponse.json({ success: true, product: updatedProduct });
    }

    if (action === 'delete-product') {
      const { id } = payload;
      await db.delete(products).where(eq(products.id, id));
      return NextResponse.json({ success: true });
    }

    if (action === 'create-video') {
      const [newVideo] = await db.insert(videos).values({
        title: payload.title,
        description: payload.description || '',
        videoUrl: payload.videoUrl,
        thumbnailUrl: payload.thumbnailUrl,
        category: payload.category || 'Collection Release',
        duration: payload.duration || '2:45',
        featured: payload.featured !== undefined ? payload.featured : true,
      }).returning();

      return NextResponse.json({ success: true, video: newVideo });
    }

    if (action === 'delete-video') {
      const { id } = payload;
      await db.delete(videos).where(eq(videos.id, id));
      return NextResponse.json({ success: true });
    }

    if (action === 'update-order') {
      const { id, status } = payload;
      await db.update(orders).set({ status }).where(eq(orders.id, id));
      return NextResponse.json({ success: true });
    }

    if (action === 'update-message') {
      const { id, status } = payload;
      await db.update(customerMessages).set({ status }).where(eq(customerMessages.id, id));
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ success: false, message: 'Invalid administrative action.' }, { status: 400 });

  } catch (err: any) {
    console.error('API Admin Route Handler Error:', err);
    return NextResponse.json({ success: false, message: 'Server database error: ' + err.message }, { status: 500 });
  }
}
