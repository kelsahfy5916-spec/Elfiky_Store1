import { NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, email, password, name, phone, address, city } = body;

    if (!email || !password) {
      return NextResponse.json({ success: false, message: 'Email and password are required.' }, { status: 400 });
    }

    const cleanEmail = email.trim().toLowerCase();

    if (action === 'login') {
      const userList = await db.select().from(users).where(eq(users.email, cleanEmail));
      
      if (userList.length === 0) {
        // Account does not exist -> let's auto create it if requested or let the client know!
        // In our flawless UX, if login fails because account not found, we auto-register and return it!
        const derivedName = cleanEmail.split('@')[0].replace(/[^a-zA-Z]/g, ' ') || 'Valued VIP Client';
        const [newUser] = await db.insert(users).values({
          name: derivedName,
          email: cleanEmail,
          password: password,
          phone: '',
          role: 'client',
          address: '',
          city: 'Egypt, South Sinai',
        }).returning();

        return NextResponse.json({
          success: true,
          autoCreated: true,
          message: `New VIP Account created automatically! Welcome, ${newUser.name}.`,
          user: {
            id: newUser.id,
            name: newUser.name,
            email: newUser.email,
            phone: newUser.phone,
            role: newUser.role,
            address: newUser.address,
            city: newUser.city,
          }
        });
      }

      const user = userList[0];
      if (user.password !== password) {
        return NextResponse.json({ success: false, message: 'Incorrect password. Please verify your security password and try again.' }, { status: 401 });
      }

      return NextResponse.json({
        success: true,
        message: `Welcome back, ${user.name}! Authenticated successfully.`,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          address: user.address,
          city: user.city,
        }
      });
    } else if (action === 'register') {
      const userList = await db.select().from(users).where(eq(users.email, cleanEmail));
      if (userList.length > 0) {
        return NextResponse.json({ success: false, message: 'This email is already registered. Please use Instant Sign In.' }, { status: 409 });
      }

      const [newUser] = await db.insert(users).values({
        name: name?.trim() || 'Valued VIP Client',
        email: cleanEmail,
        password: password,
        phone: phone?.trim() || '',
        role: 'client',
        address: address?.trim() || '',
        city: city || 'Egypt, South Sinai',
      }).returning();

      return NextResponse.json({
        success: true,
        message: `Account created successfully! Welcome to Elfiky_Store VIP, ${newUser.name}.`,
        user: {
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
          phone: newUser.phone,
          role: newUser.role,
          address: newUser.address,
          city: newUser.city,
        }
      });
    }

    return NextResponse.json({ success: false, message: 'Invalid authentication action dispatch.' }, { status: 400 });

  } catch (err: any) {
    console.error('API Authentication Route Handers Error:', err);
    return NextResponse.json({ success: false, message: 'Server backend database error: ' + err.message }, { status: 500 });
  }
}
