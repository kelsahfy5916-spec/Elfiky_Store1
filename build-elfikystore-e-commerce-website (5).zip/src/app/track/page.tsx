'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { getOrderDetails } from '@/app/actions';
import { Search, Package, Truck, CheckCircle2, Clock, MapPin, ShieldCheck, ShoppingBag, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

function TrackOrderContent() {
  const searchParams = useSearchParams();
  const initialOrderNum = searchParams ? searchParams.get('order') || '' : '';

  const [orderNumberInput, setOrderNumberInput] = useState(initialOrderNum);
  const [order, setOrder] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    if (initialOrderNum) {
      handleSearchOrder(initialOrderNum);
    }
  }, [initialOrderNum]);

  const handleSearchOrder = async (orderNumToSearch?: string) => {
    const q = (orderNumToSearch || orderNumberInput).trim();
    if (!q) return;

    setLoading(true);
    setSearched(true);
    setOrder(null);

    try {
      const res = await getOrderDetails(q);
      setOrder(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const statusList = ['Pending Verification', 'Processing', 'Shipped', 'Delivered'];
  const currentStatusIdx = order ? statusList.findIndex(s => s.toLowerCase() === order.status.toLowerCase()) : 0;

  return (
    <>
      {/* Input Box */}
      <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col sm:flex-row gap-4 items-center max-w-2xl mx-auto">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-4 w-5 h-5 text-zinc-500" />
          <input
            type="text"
            placeholder="Enter Master Order Number (e.g. ELFIKY-2910)..."
            value={orderNumberInput}
            onChange={(e) => setOrderNumberInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleSearchOrder(); }}
            className="w-full bg-zinc-900 border border-zinc-800 text-white pl-12 pr-4 py-3.5 rounded-2xl text-sm focus:outline-none focus:border-amber-500 font-mono"
          />
        </div>
        <button
          onClick={() => handleSearchOrder()}
          disabled={loading || !orderNumberInput.trim()}
          className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-black px-8 py-3.5 rounded-2xl text-xs uppercase tracking-widest transition-all shadow-lg hover:scale-105 flex-shrink-0"
        >
          {loading ? 'Searching...' : 'Track Order'}
        </button>
      </div>

      {/* Results Area */}
      <AnimatePresence mode="wait">
        {loading && (
          <div key="loading" className="text-center py-20 font-mono text-zinc-500 flex flex-col items-center gap-3">
            <span className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin"></span>
            <span>Interrogating Logistics Ledger...</span>
          </div>
        )}

        {!loading && searched && !order && (
          <motion.div key="not-found" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-zinc-950 border border-zinc-900 rounded-3xl p-16 text-center max-w-xl mx-auto mt-12">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-white">Shipment Core Not Found</h3>
            <p className="mt-2 text-zinc-400 text-xs leading-relaxed max-w-sm mx-auto">
              We could not locate an active order with the number <strong className="text-white">{orderNumberInput}</strong>. Please confirm your order receipt email.
            </p>
          </motion.div>
        )}

        {!loading && order && (
          <motion.div key="order" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-12 space-y-12">
            
            {/* Top Banner */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <span className="px-3 py-1 rounded bg-zinc-900 text-amber-400 font-mono text-xs font-bold border border-zinc-800">
                  {order.paymentMethod} &bull; Ref #{order.transactionId}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-mono mt-3 text-white select-all">
                  {order.orderNumber}
                </h2>
                <p className="text-xs text-zinc-400 mt-1 font-sans">
                  Ordered by <strong className="text-zinc-200">{order.customerName}</strong> for {order.customerCity} delivery.
                </p>
              </div>

              <div className="text-left md:text-right font-mono">
                <p className="text-xs text-zinc-500 uppercase tracking-widest">Master Ledger Sum:</p>
                <p className="text-2xl sm:text-3xl font-black text-amber-400">{order.totalAmount.toLocaleString()} EGP</p>
              </div>
            </div>

            {/* Graphical Status Bar */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-12 shadow-2xl space-y-8">
              <h3 className="font-black uppercase tracking-wider text-sm font-mono text-white flex items-center gap-2">
                <Package className="w-5 h-5 text-amber-500" />
                <span>Real-Time Fulfillment Progress: <strong className="text-amber-400 font-sans">{order.status}</strong></span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 pt-4">
                {[
                  { title: 'Pending Verification', desc: 'Financial Core Checking Receipt ID', icon: Clock },
                  { title: 'Processing', desc: 'Ateliers Cutting & Inspecting Giza Cotton', icon: Package },
                  { title: 'Shipped', desc: 'Dispatched to Express Delivery Courier', icon: Truck },
                  { title: 'Delivered', desc: 'Order Handed Securely to Client', icon: CheckCircle2 },
                ].map((st, idx) => {
                  const isDone = currentStatusIdx >= idx;
                  const isCurrent = currentStatusIdx === idx;
                  const IconComp = st.icon;

                  return (
                    <div
                      key={st.title}
                      className={`p-5 rounded-2xl border-2 transition-all flex flex-col gap-2 relative ${
                        isCurrent
                          ? 'border-amber-500 bg-amber-500/10 text-white font-black shadow-xl scale-105'
                          : isDone
                          ? 'border-emerald-500/40 bg-emerald-500/5 text-emerald-400'
                          : 'border-zinc-900 bg-zinc-950 text-zinc-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className={`p-2 rounded-xl ${isCurrent ? 'bg-amber-500 text-black' : isDone ? 'bg-emerald-500/20 text-emerald-400' : 'bg-zinc-900 text-zinc-600'}`}>
                          <IconComp className="w-5 h-5" />
                        </div>
                        {isDone && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                      </div>
                      <h4 className="text-xs font-bold uppercase tracking-wider mt-2">{st.title}</h4>
                      <p className="text-[11px] font-sans font-normal opacity-80 leading-relaxed">{st.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Purchased Pieces Summary */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
              <h3 className="font-black uppercase tracking-wider text-sm font-mono text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-500" />
                <span>Purchased Premium Apparel</span>
              </h3>

              <div className="space-y-4 divide-y divide-zinc-900">
                {order.items?.map((item: any) => (
                  <div key={item.id} className="pt-4 first:pt-0 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4 min-w-0">
                      <img src={item.productImage} alt="" className="w-16 h-20 rounded-xl object-cover bg-zinc-900 flex-shrink-0" />
                      <div className="min-w-0">
                        <h4 className="text-sm font-bold text-white truncate">{item.productTitle}</h4>
                        <p className="text-xs font-mono text-zinc-400 mt-1">Size: <strong className="text-amber-400">{item.selectedSize}</strong> &bull; Color: {item.selectedColor}</p>
                        <p className="text-xs font-mono text-zinc-500 mt-0.5">Unit: {item.price.toLocaleString()} EGP &times; {item.quantity}</p>
                      </div>
                    </div>

                    <span className="text-sm font-black font-mono text-amber-400 self-end sm:self-center">
                      {(item.price * item.quantity).toLocaleString()} EGP
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default function TrackOrderPage() {
  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Top Track Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 py-16 px-4 border-b border-zinc-800 text-center relative overflow-hidden">
        <div className="absolute top-0 right-1/4 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight">
            Shipment <span className="font-serif italic text-amber-500 font-normal">Tracking</span> Hub
          </h1>
          <p className="mt-4 text-zinc-400 text-sm sm:text-base max-w-xl mx-auto font-light leading-relaxed">
            Track your Elfiky_Store order from our master ateliers in Cairo directly to your doorstep.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <Suspense fallback={<div className="text-center py-20 font-mono text-amber-500">Loading Tracking Ledger Core...</div>}>
          <TrackOrderContent />
        </Suspense>
      </div>
    </div>
  );
}
