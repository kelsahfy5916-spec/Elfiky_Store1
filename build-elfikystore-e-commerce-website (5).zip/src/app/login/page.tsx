'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useApp, AuthUser } from '@/context/AppContext';
import { User, Lock, Mail, Phone, MapPin, Sparkles, CheckCircle, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function LoginPage() {
  const { setUser } = useApp();
  const router = useRouter();
  
  // Two pure private tabs: 'client-login' | 'client-register'
  const [activeTab, setActiveTab] = useState<'client-login' | 'client-register'>('client-login');

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Egypt, South Sinai');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const normalizeUser = (u: any): AuthUser => ({
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone || undefined,
    role: u.role,
    address: u.address || undefined,
    city: u.city || undefined,
  });

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      if (activeTab === 'client-login') {
        const response = await fetch('/api/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'login', email, password }),
        });
        
        const res = await response.json();

        if (res.success && res.user) {
          const normUser = normalizeUser(res.user);
          setUser(normUser);
          
          if (res.autoCreated) {
            setSuccessMsg(`New VIP Profile auto-registered! Welcome, ${normUser.name}.`);
          } else {
            setSuccessMsg(`Welcome back, ${normUser.name}! Authenticated successfully.`);
          }
          
          setTimeout(() => {
            if (normUser.role === 'admin') router.push('/admin');
            else router.push('/');
          }, 600);
        } else {
          setErrorMsg(res.message || 'Authentication error. Please check your credentials.');
        }

      } else if (activeTab === 'client-register') {
        if (!name.trim() || !email.trim() || !password) {
          setErrorMsg('Please complete all required registration fields.');
          setLoading(false);
          return;
        }

        const response = await fetch('/api/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'register', name, email, password, phone, address, city }),
        });

        const res = await response.json();

        if (res.success && res.user) {
          const normUser = normalizeUser(res.user);
          setUser(normUser);
          setSuccessMsg(`Profile registered successfully! Welcome to Elfiky_Store VIP, ${normUser.name}.`);
          setTimeout(() => {
            router.push('/');
          }, 600);
        } else {
          setErrorMsg(res.message || 'Registration authorization error.');
        }
      }
    } catch (err: any) {
      console.error('Login submit error:', err);
      setErrorMsg('Authentication communication error: ' + (err.message || err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[90vh] bg-gradient-to-b from-black via-zinc-950 to-black text-white flex items-center justify-center py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden font-sans">
      {/* Absolute Luxurious Ambient Lights */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-amber-500/15 via-amber-600/5 to-transparent rounded-full blur-[160px] pointer-events-none"></div>

      <div className="relative z-10 w-full max-w-xl space-y-8">
        
        {/* Flagship Brand Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-black uppercase tracking-widest shadow-xl">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>256-Bit Secure Verification Core</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white">
            Authenticate <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-600">VIP Profile</span>
          </h1>
          <p className="text-zinc-300 text-sm sm:text-base font-light leading-relaxed max-w-lg mx-auto">
            Enter your registered credentials to open your Client Profile or Master Admin Ledger. If your email is new, our financial core will register your account instantly.
          </p>
        </div>

        {/* Breathtaking Glassmorphic Authentication Window */}
        <div className="bg-zinc-950/95 border-2 border-zinc-800/90 rounded-3xl p-8 sm:p-12 shadow-2xl backdrop-blur-xl space-y-8">
          
          {/* High-Contrast Segmented Tabs */}
          <div className="grid grid-cols-2 gap-2 bg-zinc-900/90 p-2 rounded-2xl font-mono text-xs sm:text-sm font-bold border border-zinc-800">
            <button
              onClick={() => { setActiveTab('client-login'); setEmail(''); setPassword(''); setErrorMsg(''); }}
              className={`py-3.5 px-4 rounded-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                activeTab === 'client-login'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black shadow-xl scale-[1.02]'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <User className="w-4 h-4 stroke-[2.5]" />
              <span>Instant Sign In</span>
            </button>
            
            <button
              onClick={() => { setActiveTab('client-register'); setEmail(''); setPassword(''); setErrorMsg(''); }}
              className={`py-3.5 px-4 rounded-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                activeTab === 'client-register'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black shadow-xl scale-[1.02]'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <Sparkles className="w-4 h-4 stroke-[2.5]" />
              <span>Register Profile</span>
            </button>
          </div>

          {/* Dynamic Error & Success Badges */}
          <AnimatePresence>
            {errorMsg && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="p-4 rounded-2xl bg-red-500/15 border-2 border-red-500/50 text-red-400 text-xs sm:text-sm font-mono font-bold flex items-center gap-3 shadow-lg">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-ping flex-shrink-0"></span>
                <span className="leading-relaxed">{errorMsg}</span>
              </motion.div>
            )}

            {successMsg && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="p-4 rounded-2xl bg-emerald-500/15 border-2 border-emerald-500/50 text-emerald-400 text-xs sm:text-sm font-mono font-bold flex items-center gap-3 shadow-lg">
                <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span className="leading-relaxed">{successMsg}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Interactive Form */}
          <form onSubmit={handleAuthSubmit} className="space-y-6">
            {activeTab === 'client-register' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-6">
                <div>
                  <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                    Full Legal Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-4 w-5 h-5 text-amber-500" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Karim Ahmed"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl pl-13 pr-6 py-4 text-sm sm:text-base font-medium focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-4 w-5 h-5 text-amber-500" />
                      <input
                        type="tel"
                        placeholder="01068750578"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl pl-13 pr-6 py-4 text-sm sm:text-base font-mono focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                      Governorate City
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-4 w-5 h-5 text-amber-500" />
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl pl-13 pr-6 py-4 text-sm sm:text-base font-mono focus:outline-none focus:border-amber-500 transition-colors cursor-pointer shadow-inner"
                      >
                        <option value="Egypt, South Sinai">Egypt, South Sinai</option>
                        <option value="Cairo">Cairo</option>
                        <option value="Giza">Giza</option>
                        <option value="Alexandria">Alexandria</option>
                        <option value="Mansoura">Mansoura</option>
                        <option value="Tanta">Tanta</option>
                        <option value="Other">Other Governorate</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                    Detailed Delivery Destination
                  </label>
                  <input
                    type="text"
                    placeholder="Street name, Building number, Apartment..."
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl px-6 py-4 text-sm sm:text-base font-medium focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                  />
                </div>
              </motion.div>
            )}

            <div>
              <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-4 w-5 h-5 text-amber-500" />
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl pl-13 pr-6 py-4 text-sm sm:text-base font-mono focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono font-black uppercase tracking-wider text-amber-400 mb-2">
                Master Security Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-4 w-5 h-5 text-amber-500" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 text-white rounded-2xl pl-13 pr-6 py-4 text-sm sm:text-base font-mono focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                />
              </div>
            </div>

            {activeTab === 'client-login' && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-zinc-900 to-amber-500/10 border border-amber-500/30 flex items-center gap-3">
                <Zap className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <p className="text-xs text-zinc-300 leading-relaxed font-sans font-normal">
                  <strong>Automatic Registration Active:</strong> If your email is not found in our ledger, we will instantly create your VIP Legal Profile and approve your active session.
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-5 px-8 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-widest text-sm sm:text-base transition-all shadow-xl hover:shadow-amber-500/25 hover:scale-[1.02] cursor-pointer mt-4"
            >
              {loading ? (
                <>
                  <span className="w-6 h-6 rounded-full border-3 border-black border-t-transparent animate-spin"></span>
                  <span>Verifying Authorization...</span>
                </>
              ) : (
                <>
                  <span>
                    {activeTab === 'client-login' ? 'Proceed To Authorized Account' : 'Register Master Security Profile'}
                  </span>
                  <ArrowRight className="w-6 h-6 stroke-[3]" />
                </>
              )}
            </button>
          </form>

        </div>

      </div>
    </div>
  );
}
