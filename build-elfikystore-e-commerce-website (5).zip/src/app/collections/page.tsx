import React from 'react';
import { getProductsFilter } from '@/app/actions';
import MasterProductFilter from '@/components/MasterProductFilter';

export const revalidate = 0;

export default async function CollectionsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string; gender?: string }>;
}) {
  const params = await searchParams;
  const q = params.q || '';
  const category = params.category || 'All';
  const gender = params.gender || 'All';

  // Fetch all live products to power the real-time client filter engine
  const allProducts = await getProductsFilter();

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Premium Collection Master Archive Banner */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-850 to-zinc-900 py-16 px-4 border-b border-zinc-800 text-center relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight">
            The Complete <span className="font-serif italic text-amber-500 font-normal">Master</span> Archive
          </h1>
          <p className="mt-4 text-zinc-400 text-sm sm:text-base max-w-xl mx-auto font-light leading-relaxed font-sans">
            Use our highly advanced interactive multi-filter core below to search, sort, and display all our premium streetwear drops in real-time.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <MasterProductFilter
          initialProducts={allProducts}
          initialCategory={category}
          initialQuery={q}
        />
      </div>
    </div>
  );
}
