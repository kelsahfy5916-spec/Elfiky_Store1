'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { askElfikyAi } from '@/app/actions/aiAdvisor';
import { Sparkles, Bot, Ruler, Weight, UserCheck, Flame, ShoppingBag, ArrowRight, CornerDownRight, CheckCircle, Sliders } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AiStylistPage() {
  const { setQuickViewProduct } = useApp();
  
  // Interactive Slider State
  const [height, setHeight] = useState<number>(180);
  const [weight, setWeight] = useState<number>(78);
  const [fitPref, setFitPref] = useState<'oversized' | 'tailored'>('oversized');
  const [calculatedSize, setCalculatedSize] = useState<string>('L');
  const [sizeDetail, setSizeDetail] = useState<string>('Flawless Streetwear Drape. Ideal for our 450GSM Velvet Hoodies and Giza cotton drop-shoulder tees.');

  // Conversational AI State
  const [query, setQuery] = useState('');
  const [aiReply, setAiReply] = useState('');
  const [aiProducts, setAiProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Recalculate Size on slider change
  const handleCalculateSize = (newH: number, newW: number, pref: 'oversized' | 'tailored') => {
    setHeight(newH);
    setWeight(newW);
    setFitPref(pref);

    let rec = 'M';
    let detail = '';

    if (newH > 188 || newW > 95) {
      rec = pref === 'oversized' ? 'XXL' : 'XL';
      detail = 'Maximum royal structure. Gives exceptional comfort across chest and shoulders.';
    } else if (newH > 182 || newW > 85) {
      rec = pref === 'oversized' ? 'XXL' : 'XL';
      detail = 'Impeccable drop-shoulder presence. Sleeves will rest beautifully at the knuckles.';
    } else if (newH > 175 || newW > 74) {
      rec = pref === 'oversized' ? 'XL' : 'L';
      detail = 'Flawless classic streetwear balance. Perfect proportions for layered outerwear dressing.';
    } else if (newH > 168 || newW > 64) {
      rec = pref === 'oversized' ? 'L' : 'M';
      detail = 'Streamlined European silhouette. Tailored perfectly for daily active city life.';
    } else {
      rec = pref === 'oversized' ? 'M' : 'S';
      detail = 'Snug yet comfortable luxury drape. Prevents excessive billowing.';
    }

    setCalculatedSize(rec);
    setSizeDetail(detail);
  };

  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || loading) return;

    const q = query;
    setQuery('');
    setLoading(true);

    try {
      const res = await askElfikyAi(q, height, weight, fitPref);
      setAiReply(res.answer);
      setAiProducts(res.products || []);
    } catch (err) {
      setAiReply("Our AI Core is experiencing high styling volume. Please consult our human stylists!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Page Flagship Header */}
      <div className="bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 py-20 px-4 border-b border-zinc-800 text-center relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-gradient-to-tr from-amber-500/10 to-amber-600/5 rounded-full blur-[140px] pointer-events-none"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono uppercase tracking-widest mb-4">
            <Sparkles className="w-4 h-4 animate-spin" style={{ animationDuration: '6s' }} />
            <span>Virtual Ateliers | Precision Sizing Core</span>
          </div>
          <h1 className="text-4xl sm:text-7xl font-black uppercase tracking-tight">
            Elfiky AI Stylist <span className="font-serif italic text-amber-500 font-normal">&</span> Advisor
          </h1>
          <p className="mt-6 text-zinc-400 text-base sm:text-lg max-w-2xl mx-auto font-light leading-relaxed">
            Eliminate sizing guesswork entirely. Use our dynamic European measurement matrix below to discover your perfect Elfiky Master fit instantly.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* LEFT 7 COLS: Interactive Slider Size Tool */}
          <div className="lg:col-span-7 bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl flex flex-col justify-between space-y-8">
            <div>
              <div className="flex items-center gap-3 border-b border-zinc-900 pb-4">
                <div className="p-2.5 bg-amber-500 rounded-2xl text-black font-black">
                  <Sliders className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight uppercase">Master Measurement Matrix</h2>
                  <p className="text-xs text-zinc-400 font-mono">Adjust sliders to input your biological height and weight</p>
                </div>
              </div>

              {/* Sliders */}
              <div className="space-y-8 mt-8">
                {/* Height */}
                <div className="bg-zinc-900/60 border border-zinc-800/80 p-6 rounded-2xl">
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-xs font-mono font-bold uppercase text-zinc-300 flex items-center gap-2">
                      <Ruler className="w-4 h-4 text-amber-500" />
                      <span>Body Height</span>
                    </label>
                    <span className="text-2xl font-black font-mono text-amber-400">{height} <span className="text-xs font-sans font-normal text-zinc-400">CM</span></span>
                  </div>
                  <input
                    type="range"
                    min={150}
                    max={210}
                    value={height}
                    onChange={(e) => handleCalculateSize(Number(e.target.value), weight, fitPref)}
                    className="w-full accent-amber-500 h-2 bg-zinc-950 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-zinc-600 mt-2">
                    <span>150 cm</span>
                    <span>180 cm</span>
                    <span>210 cm</span>
                  </div>
                </div>

                {/* Weight */}
                <div className="bg-zinc-900/60 border border-zinc-800/80 p-6 rounded-2xl">
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-xs font-mono font-bold uppercase text-zinc-300 flex items-center gap-2">
                      <Weight className="w-4 h-4 text-amber-500" />
                      <span>Body Weight</span>
                    </label>
                    <span className="text-2xl font-black font-mono text-amber-400">{weight} <span className="text-xs font-sans font-normal text-zinc-400">KG</span></span>
                  </div>
                  <input
                    type="range"
                    min={45}
                    max={140}
                    value={weight}
                    onChange={(e) => handleCalculateSize(height, Number(e.target.value), fitPref)}
                    className="w-full accent-amber-500 h-2 bg-zinc-950 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-zinc-600 mt-2">
                    <span>45 kg</span>
                    <span>90 kg</span>
                    <span>140 kg</span>
                  </div>
                </div>

                {/* Aesthetic Fit Preference */}
                <div className="space-y-3">
                  <label className="block text-xs font-mono font-bold uppercase text-zinc-400">Aesthetic Fit Preference</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => handleCalculateSize(height, weight, 'oversized')}
                      className={`p-4 rounded-2xl border text-left transition-all ${
                        fitPref === 'oversized'
                          ? 'bg-amber-500 text-black border-amber-400 font-black shadow-lg scale-102'
                          : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="uppercase">👑 Oversized Drape</span>
                        {fitPref === 'oversized' && <CheckCircle className="w-4 h-4 fill-black text-amber-500" />}
                      </div>
                      <p className="text-[11px] font-light mt-1 opacity-90 leading-tight">Signature luxury drop shoulder & airy volume.</p>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleCalculateSize(height, weight, 'tailored')}
                      className={`p-4 rounded-2xl border text-left transition-all ${
                        fitPref === 'tailored'
                          ? 'bg-amber-500 text-black border-amber-400 font-black shadow-lg scale-102'
                          : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="uppercase">⚡ Sharp Tailored</span>
                        {fitPref === 'tailored' && <CheckCircle className="w-4 h-4 fill-black text-amber-500" />}
                      </div>
                      <p className="text-[11px] font-light mt-1 opacity-90 leading-tight">European tapered classic proportions.</p>
                    </button>
                  </div>
                </div>

              </div>
            </div>

            {/* Bottom Final Size Calculation Banner */}
            <motion.div
              key={calculatedSize}
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-black p-8 rounded-3xl shadow-2xl flex items-center justify-between gap-6 mt-8"
            >
              <div>
                <p className="text-xs font-mono font-bold uppercase tracking-widest opacity-80 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4" /> Professional Result:
                </p>
                <div className="text-4xl sm:text-6xl font-black font-mono tracking-tighter mt-1 flex items-baseline gap-2">
                  <span>Size</span>
                  <span className="text-5xl sm:text-7xl underline decoration-black">{calculatedSize}</span>
                </div>
                <p className="text-xs font-medium max-w-md mt-2 font-sans leading-relaxed opacity-95">
                  {sizeDetail}
                </p>
              </div>

              <a
                href="/collections"
                className="bg-black text-white hover:bg-zinc-900 font-black p-5 rounded-2xl flex items-center justify-center shadow-2xl transition-transform hover:scale-110 flex-shrink-0"
                title="Shop Calculated Size"
              >
                <ArrowRight className="w-8 h-8 text-amber-400" />
              </a>
            </motion.div>
          </div>

          {/* RIGHT 5 COLS: AI Direct Stylist Core Consultation */}
          <div className="lg:col-span-5 bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 border-b border-zinc-900 pb-4">
                <div className="p-2.5 bg-gradient-to-tr from-amber-500 to-amber-600 rounded-2xl text-black font-black">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight uppercase">AI Stylist Consult</h2>
                  <p className="text-xs text-zinc-400 font-mono">Chat directly with the Elfiky Artificial Core</p>
                </div>
              </div>

              <p className="text-zinc-400 text-xs leading-relaxed mt-6">
                Need advice on matching our *Classic Linen Trousers* with the *Cyberpunk Outerwear* for an upcoming gala or travel destination? Type your inquiry below.
              </p>

              {/* Input box */}
              <form onSubmit={handleAskQuestion} className="mt-6 space-y-4">
                <textarea
                  rows={4}
                  required
                  placeholder="e.g. I am attending an evening gallery release in Giza this Friday. What is your most luxurious outerwear combination?"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white p-5 rounded-2xl text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-zinc-600 font-sans"
                />
                <button
                  type="submit"
                  disabled={loading || !query.trim()}
                  className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-black py-4 px-6 rounded-2xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-xl hover:scale-102"
                >
                  {loading ? (
                    <>
                      <Bot className="w-4 h-4 animate-spin" />
                      <span>Synthesizing Outfit Matrix...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Consult Stylist Core</span>
                    </>
                  )}
                </button>
              </form>

              {/* Reply Area */}
              {aiReply && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-8 p-6 bg-zinc-900 border border-zinc-800 rounded-3xl space-y-4"
                >
                  <h4 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" /> Stylist Core Dispatch:
                  </h4>
                  <div className="text-sm leading-relaxed text-zinc-200 whitespace-pre-line font-sans">
                    {aiReply}
                  </div>
                </motion.div>
              )}
            </div>

            {/* AI Product Suggestions */}
            {aiProducts && aiProducts.length > 0 && (
              <div className="pt-8 border-t border-zinc-900 mt-8 space-y-4">
                <p className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1">
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-500" />
                  <span>Curated Pieces In Dispatch:</span>
                </p>
                <div className="space-y-3">
                  {aiProducts.map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => setQuickViewProduct(prod)}
                      className="group p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500 flex items-center gap-4 cursor-pointer transition-all hover:scale-102"
                    >
                      <img src={prod.images[0]} alt="" className="w-14 h-16 rounded-xl object-cover flex-shrink-0 bg-zinc-950" />
                      <div className="flex-1 min-w-0">
                        <h5 className="text-xs font-bold text-white truncate group-hover:text-amber-400 transition-colors">
                          {prod.title}
                        </h5>
                        <p className="text-xs font-mono text-amber-400 font-bold mt-1">
                          {prod.price.toLocaleString()} EGP
                        </p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-zinc-500 group-hover:text-amber-400 transition-colors flex-shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>
      </div>
    </div>
  );
}
