'use client';

import React, { useState } from 'react';
import { sendMessage } from '@/app/actions';
import { Send, Phone, Mail, MapPin, MessageSquare, Clock, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please provide your complete contact details and message.');
      return;
    }

    setLoading(true);

    try {
      const res = await sendMessage({ name, email, phone, message });
      if (res.success) {
        setSuccess('Your dispatch has been successfully transmitted to our Master Ateliers! We will reply within 2 hours.');
        setName('');
        setEmail('');
        setPhone('');
        setMessage('');
      } else {
        setError(res.message || 'Error sending message.');
      }
    } catch (err: any) {
      setError(err.message || 'Transmission error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 py-16 px-4 border-b border-zinc-800 text-center relative overflow-hidden">
        <div className="absolute top-0 left-1/4 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight">
            Contact Master <span className="font-serif italic text-amber-500 font-normal">Ateliers</span>
          </h1>
          <p className="mt-4 text-zinc-400 text-sm sm:text-base max-w-xl mx-auto font-light leading-relaxed">
            Reach out for bespoke tailoring, global brand partnerships, or urgent VIP order adjustments.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left 5 Cols: Address & Directory */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-8 sm:p-10 shadow-2xl space-y-6">
              <h3 className="font-black text-xl uppercase tracking-wide text-white flex items-center gap-2">
                <MapPin className="w-6 h-6 text-amber-500" />
                <span>South Sinai Master Headquarters</span>
              </h3>
              
              <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                Our cutting-edge product design labs and Giza cotton verification ateliers are located in the prestigious South Sinai business center.
              </p>

              <div className="space-y-4 pt-4 border-t border-zinc-900 font-mono text-xs">
                <div className="flex items-start gap-3 text-zinc-300">
                  <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0 mt-1" />
                  <span>Egypt, South Sinai</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-300">
                  <Phone className="w-4 h-4 text-amber-500 flex-shrink-0" />
                  <span>+20 1068750578</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-300">
                  <Mail className="w-4 h-4 text-amber-500 flex-shrink-0" />
                  <span>care@elfikystore.com</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-300">
                  <Clock className="w-4 h-4 text-amber-500 flex-shrink-0" />
                  <span>Daily Dispatch Hours: 09:00 AM &ndash; 11:00 PM</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right 7 Cols: Form */}
          <div className="lg:col-span-7 bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-6 h-6 text-amber-500" />
              <div>
                <h3 className="font-black text-xl uppercase tracking-wide text-white">Transmit Direct Inquiries</h3>
                <p className="text-xs text-zinc-400 font-mono">Fill out the fields to dispatch directly to our customer care manager</p>
              </div>
            </div>

            {error && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-mono font-bold">
                {error}
              </motion.div>
            )}

            {success && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <span>{success}</span>
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Karim Ahmed"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="client@elfiky.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Mobile Wallet Phone (Optional)</label>
                <input
                  type="tel"
                  placeholder="01068750578"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Bespoke Message / Styling Query</label>
                <textarea
                  rows={5}
                  required
                  placeholder="State your precise instructions or questions here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl p-4 text-sm focus:outline-none focus:border-amber-500 font-sans"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-4 px-8 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-xl"
              >
                {loading ? (
                  <>
                    <span className="w-5 h-5 rounded-full border-2 border-black border-t-transparent animate-spin"></span>
                    <span>Transmitting Dispatch...</span>
                  </>
                ) : (
                  <>
                    <span>Send Dispatch To Headquarters</span>
                    <Send className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

          </div>

        </div>
      </div>
    </div>
  );
}
