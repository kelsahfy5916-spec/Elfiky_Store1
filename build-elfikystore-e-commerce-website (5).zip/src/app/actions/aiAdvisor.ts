'use server';

import { getProductsFilter } from './index';

export async function askElfikyAi(userQuery: string, userHeight?: number, userWeight?: number, fitPreference?: string) {
  try {
    const q = userQuery.toLowerCase();
    let responseText = '';
    let suggestedProductSlugs: string[] = [];

    // All products to search through
    const products = await getProductsFilter();

    // 1. SIZING LOGIC if height/weight provided or mentioned in query
    let detectedHeight = userHeight;
    let detectedWeight = userWeight;

    // Try parsing from text if not explicitly passed
    const heightMatch = q.match(/(\d{3})\s*(?:cm|sm)/);
    const weightMatch = q.match(/(\d{2,3})\s*(?:kg|kilo)/);

    if (heightMatch) detectedHeight = parseInt(heightMatch[1], 10);
    if (weightMatch) detectedWeight = parseInt(weightMatch[1], 10);

    if (detectedHeight && detectedWeight) {
      // Professional BMI / standard fashion sizing formula
      let recommendedSize = 'M';
      if (detectedHeight > 188 || detectedWeight > 95) recommendedSize = 'XXL';
      else if (detectedHeight > 182 || detectedWeight > 85) recommendedSize = 'XL';
      else if (detectedHeight > 175 || detectedWeight > 74) recommendedSize = 'L';
      else if (detectedHeight < 165 || detectedWeight < 60) recommendedSize = 'S';

      if (fitPreference === 'oversized' && recommendedSize !== 'XXL') {
        // bump one size up for oversized if requested
        const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
        const idx = sizes.indexOf(recommendedSize);
        if (idx !== -1 && idx < 4) recommendedSize = sizes[idx + 1];
      }

      responseText += `📐 **Size Recommendation:** Based on your measurements (${detectedHeight}cm, ${detectedWeight}kg), our Elfiky AI sizing algorithm recommends **Size ${recommendedSize}**.\n\n`;
      if (fitPreference === 'oversized') {
        responseText += `💡 *Note:* Since you prefer an oversized aesthetic, we factored in our signature drop-shoulder roominess.\n\n`;
      }
    } else if (q.includes('size') || q.includes('fit') || q.includes('measure') || q.includes('how big')) {
      responseText += `📐 **Elfiky Sizing Guide:** Our pieces are crafted with true advanced European & luxury streetwear sizing.\n- For our **Oversized pieces** (like our T-shirts and Velvet Hoodies), stick to your regular size for a flawless streetwear drape.\n- For our **Tailored Linen & Trench Coats**, we recommend measuring your chest/shoulders or telling me your exact height & weight in cm and kg!\n\n`;
    }

    // 2. PRODUCT & STYLE MATCHING
    if (q.includes('winter') || q.includes('cold') || q.includes('jacket') || q.includes('coat') || q.includes('hoodie')) {
      responseText += `❄️ **Winter & Outerwear Recommendations:** For premium insulation and supreme royal presence, our best picks are:\n- **Premium Royal Velvet Hoodie (Black Edition)** (Ultra-plush 450GSM)\n- **Sleek Double-Breasted Wool Trench Coat**\n- **Cyberpunk Waterproof Tech-Wear Jacket**\n\n`;
      suggestedProductSlugs.push('premium-royal-velvet-hoodie-black', 'sleek-double-breasted-wool-trench-coat', 'cyberpunk-waterproof-techwear-jacket');
    } else if (q.includes('summer') || q.includes('hot') || q.includes('light') || q.includes('tshirt') || q.includes('t-shirt') || q.includes('linen')) {
      responseText += `☀️ **Summer & Breathable Staples:** Crafted for extreme comfort in Egyptian heat:\n- **Oversized Streetwear Heavy Cotton T-Shirt** (100% Giza Egyptian Cotton)\n- **Classic Tailored Linen Trousers** (Italian cut)\n\n`;
      suggestedProductSlugs.push('oversized-streetwear-heavy-cotton-tshirt', 'classic-tailored-linen-trousers');
    } else if (q.includes('bag') || q.includes('accessory') || q.includes('scarf') || q.includes('gift')) {
      responseText += `💎 **Luxurious Elfiky Accessories:** Elevate your outfit with our bespoke detailing:\n- **Elfiky Premium Leather Crossbody Bag**\n- **Elfiky Signature Monogram Silk Scarf**\n\n`;
      suggestedProductSlugs.push('elfiky-premium-leather-crossbody-bag', 'elfiky-signature-monogram-silk-scarf');
    } else if (q.includes('payment') || q.includes('vodafone') || q.includes('instapay') || q.includes('delivery') || q.includes('cash')) {
      responseText += `💳 **Payment & Secure Checkout:** We proudly support instant Egyptian mobile wallets & banking networks!\n- **Vodafone Cash, Etisalat Cash, Orange Cash, We Cash, & InstaPay**.\n- Express shipping to Cairo & Giza within 24-48 hours. Nationwide delivery within 3-4 days.\n\n`;
    } else if (!detectedHeight) {
      responseText += `✨ **Welcome to Elfiky AI Fashion Advisor!**\nWhether you're looking for the perfect Cyberpunk outfit, premium Giza cotton tees, or need exact size calculations, I'm here to curate your premium look. You can reply with your height & weight (e.g. '182cm 78kg') or tell me your occasion!\n\n`;
      suggestedProductSlugs.push('premium-royal-velvet-hoodie-black', 'oversized-streetwear-heavy-cotton-tshirt');
    }

    // Filter suggested products to send full objects
    const recommendedProducts = products.filter(p => suggestedProductSlugs.includes(p.slug)).slice(0, 3);
    if (recommendedProducts.length === 0 && products.length > 0) {
      recommendedProducts.push(products[0], products[1]);
    }

    return {
      success: true,
      answer: responseText,
      products: recommendedProducts,
    };
  } catch (error) {
    console.error('AI Error:', error);
    return {
      success: false,
      answer: "I am having trouble connecting to the Elfiky AI styling core. Please explore our premium collections above or contact our human customer care team!",
      products: [],
    };
  }
}
