'use server';

import { db } from '@/db';
import { users, products, videos, orders, orderItems, customerMessages } from '@/db/schema';
import { seedUsers, seedProducts, seedVideos } from '@/db/seedData';
import { eq, desc, ilike, and } from 'drizzle-orm';

// ----------------------------------------------------
// SEEDING
// ----------------------------------------------------
export async function seedDatabase() {
  try {
    const existing = await db.select().from(products).limit(1);
    if (existing.length === 0) {
      await db.insert(users).values(seedUsers);
      await db.insert(products).values(seedProducts);
      await db.insert(videos).values(seedVideos);
      return { success: true, message: 'Database seeded successfully with premium Elfiky Store data!' };
    } else {
      // Check if the DB has the updated categories (e.g. 'Shirts' & 'Accessories')
      const accCheck = await db.select().from(products).where(eq(products.category, 'Accessories')).limit(1);
      if (accCheck.length === 0) {
        await db.delete(orderItems);
        await db.delete(products);
        await db.insert(products).values(seedProducts);
      }
    }
    return { success: true, message: 'Database ready and synchronized.' };
  } catch (error) {
    console.error('Seeding error:', error);
    return { success: false, message: 'Failed to seed database.' };
  }
}

export async function forceResetDatabase() {
  try {
    await db.delete(orderItems);
    await db.delete(orders);
    await db.delete(customerMessages);
    await db.delete(videos);
    await db.delete(products);
    await db.delete(users);

    await db.insert(users).values(seedUsers);
    await db.insert(products).values(seedProducts);
    await db.insert(videos).values(seedVideos);

    return { success: true, message: 'Database completely reset and reseeded!' };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// ----------------------------------------------------
// AUTHENTICATION (Simulated for flawless UX)
// ----------------------------------------------------
export async function login(email: string, pass: string) {
  try {
    const userList = await db.select().from(users).where(eq(users.email, email.trim().toLowerCase()));
    if (userList.length === 0) {
      return { success: false, message: 'Account not found. Please register or check your email.' };
    }
    const user = userList[0];
    if (user.password !== pass) {
      return { success: false, message: 'Incorrect password. Please try again.' };
    }
    return {
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        address: user.address,
        city: user.city,
      }
    };
  } catch (err: any) {
    console.error('Login action database error:', err);
    return { success: false, message: 'Server database connection error: ' + err.message };
  }
}

export async function registerClient(data: { name: string; email: string; pass: string; phone?: string; address?: string; city?: string }) {
  try {
    const existing = await db.select().from(users).where(eq(users.email, data.email.trim().toLowerCase()));
    if (existing.length > 0) {
      return { success: false, message: 'Email is already registered. Please login.' };
    }
    const [newUser] = await db.insert(users).values({
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      password: data.pass,
      phone: data.phone || '',
      role: 'client',
      address: data.address || '',
      city: data.city || 'Cairo',
    }).returning();

    return {
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        address: newUser.address,
        city: newUser.city,
      }
    };
  } catch (e: any) {
    return { success: false, message: e.message || 'Error registering account' };
  }
}

// ----------------------------------------------------
// PRODUCTS
// ----------------------------------------------------
export async function getProductsFilter(query?: string, category?: string, gender?: string) {
  try {
    let conditions: any[] = [];
    
    if (query && query.trim() !== '') {
      conditions.push(ilike(products.title, `%${query.trim()}%`));
    }
    if (category && category !== 'All') {
      conditions.push(eq(products.category, category));
    }
    if (gender && gender !== 'All') {
      conditions.push(eq(products.gender, gender));
    }

    if (conditions.length > 0) {
      return await db.select().from(products).where(and(...conditions)).orderBy(desc(products.featured), desc(products.createdAt));
    } else {
      return await db.select().from(products).orderBy(desc(products.featured), desc(products.createdAt));
    }
  } catch (err) {
    console.error('getProductsFilter database error:', err);
    return [];
  }
}

export async function getProductBySlug(slug: string) {
  const list = await db.select().from(products).where(eq(products.slug, slug));
  return list[0] || null;
}

// Admin Operations
export async function updateProductAdmin(id: number, updates: Partial<typeof products.$inferInsert>) {
  try {
    await db.update(products).set(updates).where(eq(products.id, id));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

export async function createProductAdmin(data: {
  title: string;
  slug: string;
  description: string;
  price: number;
  originalPrice: number | null;
  category: string;
  gender: string;
  images: string[];
  sizes: string[];
  colors: string[];
  stock: number;
  featured: boolean;
  newArrival: boolean;
}) {
  try {
    await db.insert(products).values({
      ...data,
      rating: '4.9',
      reviewCount: 15,
    });
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

export async function deleteProductAdmin(id: number) {
  try {
    await db.delete(products).where(eq(products.id, id));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

// ----------------------------------------------------
// VIDEOS SHOWCASE
// ----------------------------------------------------
export async function getAllVideos() {
  try {
    return await db.select().from(videos).orderBy(desc(videos.featured), desc(videos.createdAt));
  } catch (err) {
    console.error('getAllVideos error:', err);
    return [];
  }
}

export async function createVideoAdmin(data: {
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  category: string;
  duration: string;
  featured: boolean;
}) {
  try {
    await db.insert(videos).values(data);
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

export async function deleteVideoAdmin(id: number) {
  try {
    await db.delete(videos).where(eq(videos.id, id));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

// ----------------------------------------------------
// ORDERS & PAYMENT (Vodafone/Etisalat/Orange/We/InstaPay)
// ----------------------------------------------------
export async function createOrder(data: {
  userId?: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  paymentMethod: string;
  paymentPhoneOrInsta: string;
  transactionId: string;
  totalAmount: number;
  notes?: string;
  items: {
    productId: number;
    productTitle: string;
    price: number;
    quantity: number;
    selectedSize: string;
    selectedColor: string;
    productImage: string;
  }[];
}) {
  try {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `ELFIKY-${Date.now().toString().slice(-4)}${randomNum}`;

    const [newOrder] = await db.insert(orders).values({
      orderNumber,
      userId: data.userId || null,
      customerName: data.customerName.trim(),
      customerEmail: data.customerEmail.trim(),
      customerPhone: data.customerPhone.trim(),
      customerAddress: data.customerAddress.trim(),
      customerCity: data.customerCity.trim(),
      paymentMethod: data.paymentMethod,
      paymentPhoneOrInsta: data.paymentPhoneOrInsta.trim(),
      transactionId: data.transactionId.trim(),
      status: 'Pending Verification',
      totalAmount: data.totalAmount,
      notes: data.notes || '',
    }).returning();

    // Insert order items
    const itemsToInsert = data.items.map(item => ({
      orderId: newOrder.id,
      productId: item.productId,
      productTitle: item.productTitle,
      price: item.price,
      quantity: item.quantity,
      selectedSize: item.selectedSize,
      selectedColor: item.selectedColor,
      productImage: item.productImage,
    }));

    await db.insert(orderItems).values(itemsToInsert);

    return { success: true, orderNumber };
  } catch (e: any) {
    console.error('Order creation error:', e);
    return { success: false, message: e.message };
  }
}

export async function getOrderDetails(orderNumber: string) {
  const orderList = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber.trim()));
  if (orderList.length === 0) return null;
  const order = orderList[0];
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return { ...order, items };
}

// Admin order management
export async function getAllOrders() {
  try {
    const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt));
    const populated = await Promise.all(allOrders.map(async o => {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      return { ...o, items };
    }));
    return populated;
  } catch (err) {
    console.error('getAllOrders error:', err);
    return [];
  }
}

export async function updateOrderStatusAdmin(orderId: number, status: string) {
  try {
    await db.update(orders).set({ status }).where(eq(orders.id, orderId));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

// ----------------------------------------------------
// CUSTOMER MESSAGES / CONTACT
// ----------------------------------------------------
export async function sendMessage(data: { name: string; email: string; phone?: string; message: string }) {
  try {
    await db.insert(customerMessages).values({
      senderName: data.name,
      senderEmail: data.email,
      senderPhone: data.phone || '',
      message: data.message,
    });
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}

export async function getCustomerMessagesAdmin() {
  try {
    return await db.select().from(customerMessages).orderBy(desc(customerMessages.createdAt));
  } catch (err) {
    console.error('getCustomerMessagesAdmin error:', err);
    return [];
  }
}

export async function updateMessageStatusAdmin(id: number, status: string) {
  try {
    await db.update(customerMessages).set({ status }).where(eq(customerMessages.id, id));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
}
