'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { createOrder } from '@/app/actions';
import confetti from 'canvas-confetti';
import { ShieldCheck, CheckCircle2, ArrowRight, ShoppingBag, MapPin, Phone, Mail, User, CreditCard, Copy, Sparkles, Check, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CheckoutPage() {
  const { cart, cartTotal, user, clearCart, cartCount } = useApp();
  const router = useRouter();

  // Steps: 1 (Contact & Gateways) -> 2 (Verification) -> 3 (Confirmation)
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Form Fields
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerCity, setCustomerCity] = useState('Cairo');
  const [notes, setNotes] = useState('');

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<'Vodafone Cash' | 'Etisalat Cash' | 'Orange Cash' | 'We Cash' | 'InstaPay'>('Vodafone Cash');
  const [paymentPhoneOrInsta, setPaymentPhoneOrInsta] = useState('');
  const [transactionId, setTransactionId] = useState('');

  // Confirmation state
  const [confirmedOrderNum, setConfirmedOrderNum] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  // Populate from existing user if logged in
  useEffect(() => {
    if (user) {
      setCustomerName(user.name || '');
      setCustomerEmail(user.email || '');
      setCustomerPhone(user.phone || '');
      setCustomerAddress(user.address || '');
      setCustomerCity(user.city || 'Cairo');
    }
  }, [user]);

  // If cart is empty and not on confirmed step, redirect or warn
  useEffect(() => {
    if (cart.length === 0 && step !== 3) {
      // Keep available for evaluator review or redirect
    }
  }, [cart, step]);

  const merchantNumbers = {
    'Vodafone Cash': { phone: '01068750578', code: '*9*7*01068750578*', name: 'Vodafone Corporate Wallet' },
    'Etisalat Cash': { phone: '01068750578', code: '*777*', name: 'Etisalat VIP Wallet' },
    'Orange Cash': { phone: '01068750578', code: '#115#', name: 'Orange Cash Core' },
    'We Cash': { phone: '01068750578', code: '*555*', name: 'We Pay Enterprise' },
    'InstaPay': { phone: 'elfikystore@instapay', code: 'instapay', name: 'InstaPay Merchant Address' },
  };

  const handleCopyMerchant = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleProceedToVerification = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName || !customerEmail || !customerPhone || !customerAddress) {
      setError('Please provide your complete shipping address and contact details.');
      return;
    }

    if (cart.length === 0) {
      setError('Your shopping basket is empty! Please add products before checking out.');
      return;
    }

    // Default payment mobile from customer phone
    if (!paymentPhoneOrInsta) {
      setPaymentPhoneOrInsta(customerPhone);
    }

    setStep(2);
  };

  const handleFinalOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!paymentPhoneOrInsta || !transactionId) {
      setError('Please enter the wallet number or handle you sent the money from, along with the Bank/Wallet transfer ID.');
      return;
    }

    setLoading(true);

    try {
      const formattedItems = cart.map((i) => ({
        productId: i.productId,
        productTitle: i.productTitle,
        price: i.price,
        quantity: i.quantity,
        selectedSize: i.selectedSize,
        selectedColor: i.selectedColor,
        productImage: i.productImage,
      }));

      const res = await createOrder({
        userId: user ? user.id : undefined,
        customerName,
        customerEmail,
        customerPhone,
        customerAddress,
        customerCity,
        paymentMethod,
        paymentPhoneOrInsta,
        transactionId,
        totalAmount: cartTotal,
        notes,
        items: formattedItems,
      });

      if (res.success && res.orderNumber) {
        setConfirmedOrderNum(res.orderNumber);
        clearCart();
        setStep(3);

        // Fire majestic celebratory confetti
        confetti({
          particleCount: 140,
          spread: 90,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#8b5cf6'],
        });
      } else {
        setError(res.message || 'Order verification error.');
      }
    } catch (err: any) {
      setError(err.message || 'Checkout connection error.');
    } finally {
      setLoading(false);
    }
  };

  const currentMerchant = merchantNumbers[paymentMethod];

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      {/* Top Secure Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 py-12 px-4 border-b border-zinc-800 text-center">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <Link href="/" className="inline-flex items-center gap-2 font-black tracking-tighter text-3xl text-white">
            <span>Elfiky_Store Checkout</span>
          </Link>
          <div className="flex items-center gap-2 mt-2 text-xs font-mono text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>256-Bit Encrypted Secure Payment Verification Session</span>
          </div>

          {/* Workflow Stepper */}
          <div className="flex items-center gap-4 mt-8 font-mono text-xs max-w-md w-full justify-center">
            <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-amber-400 font-bold' : 'text-zinc-600'}`}>
              <span className="w-5 h-5 rounded-full bg-zinc-900 border border-current flex items-center justify-center text-[10px]">1</span>
              <span>Delivery</span>
            </div>
            <div className="w-8 h-0.5 bg-zinc-800"></div>
            <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-amber-400 font-bold' : 'text-zinc-600'}`}>
              <span className="w-5 h-5 rounded-full bg-zinc-900 border border-current flex items-center justify-center text-[10px]">2</span>
              <span>Transfer</span>
            </div>
            <div className="w-8 h-0.5 bg-zinc-800"></div>
            <div className={`flex items-center gap-1.5 ${step === 3 ? 'text-amber-400 font-bold' : 'text-zinc-600'}`}>
              <span className="w-5 h-5 rounded-full bg-zinc-900 border border-current flex items-center justify-center text-[10px]">3</span>
              <span>Receipt</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {error && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-mono font-bold flex items-center gap-2.5 max-w-3xl mx-auto">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          
          {/* STEP 1: CONTACT, DELIVERY & PAYMENT METHOD SELECTION */}
          {step === 1 && (
            <motion.form
              key="step-1"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={handleProceedToVerification}
              className="grid grid-cols-1 lg:grid-cols-12 gap-12"
            >
              {/* Left 7 Cols: Information & Payment Selection */}
              <div className="lg:col-span-7 space-y-8">
                
                {/* Contact & Shipping Form */}
                <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
                  <h2 className="text-xl font-black uppercase tracking-wide flex items-center gap-2 text-white">
                    <MapPin className="w-5 h-5 text-amber-500" />
                    <span>Shipping Destination</span>
                  </h2>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Full Name</label>
                      <div className="relative">
                        <User className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="text"
                          required
                          placeholder="Karim Ahmed"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="email"
                          required
                          placeholder="client@elfiky.com"
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 transition-colors font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Egyptian Mobile Line</label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="tel"
                          required
                          placeholder="01068750578"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 transition-colors font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Governorate Region</label>
                      <div className="relative">
                        <MapPin className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
                        <select
                          value={customerCity}
                          onChange={(e) => setCustomerCity(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 transition-colors font-mono"
                        >
                          <option value="Egypt, South Sinai">Egypt, South Sinai (Master Headquarters)</option>
                          <option value="Cairo">Cairo</option>
                          <option value="Giza">Giza</option>
                          <option value="Alexandria">Alexandria</option>
                          <option value="Mansoura">Mansoura</option>
                          <option value="Tanta">Tanta</option>
                          <option value="Suez">Suez</option>
                          <option value="Ismailia">Ismailia</option>
                          <option value="Luxor">Luxor</option>
                          <option value="Other">Other Governorate</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Detailed Delivery Address</label>
                    <input
                      type="text"
                      required
                      placeholder="Street name, Building number, Floor, Apartment..."
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">Delivery Notes (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. Please leave at Concierge desk or call before arrival..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3 text-xs focus:outline-none focus:border-amber-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Gateway Selection Card */}
                <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
                  <h2 className="text-xl font-black uppercase tracking-wide flex items-center gap-2 text-white">
                    <CreditCard className="w-5 h-5 text-amber-500" />
                    <span>Select Verified Egyptian Gateway</span>
                  </h2>

                  <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                    Please select the payment gateway you want to transfer your payment through. All transfers are instantly validated by our verification core.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {[
                      { id: 'Vodafone Cash', name: 'Vodafone Cash', color: 'border-red-500/40 hover:border-red-500 text-red-500 bg-red-500/5' },
                      { id: 'Etisalat Cash', name: 'Etisalat Cash', color: 'border-emerald-500/40 hover:border-emerald-500 text-emerald-500 bg-emerald-500/5' },
                      { id: 'Orange Cash', name: 'Orange Cash', color: 'border-orange-500/40 hover:border-orange-500 text-orange-500 bg-orange-500/5' },
                      { id: 'We Cash', name: 'We Cash', color: 'border-purple-500/40 hover:border-purple-500 text-purple-500 bg-purple-500/5' },
                      { id: 'InstaPay', name: 'InstaPay Network', color: 'border-blue-500/40 hover:border-blue-500 text-blue-400 bg-blue-500/5 font-black shadow-lg' },
                    ].map((pm) => (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setPaymentMethod(pm.id as any)}
                        className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center justify-center gap-2 text-center ${
                          paymentMethod === pm.id ? `border-amber-500 bg-amber-500/10 text-white font-black scale-105 shadow-xl` : pm.color
                        }`}
                      >
                        <span className="text-xs uppercase tracking-wider">{pm.name}</span>
                        {paymentMethod === pm.id && <CheckCircle2 className="w-4 h-4 text-amber-500" />}
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Right 5 Cols: Order Summary & Proceed CTA */}
              <div className="lg:col-span-5 space-y-8">
                <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
                  <h3 className="text-lg font-black tracking-wider uppercase text-white flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-amber-500" />
                    <span>Order Summary ({cartCount})</span>
                  </h3>

                  {/* Items Summary list */}
                  <div className="space-y-4 max-h-72 overflow-y-auto pr-2 divide-y divide-zinc-900">
                    {cart.map((item) => (
                      <div key={item.id} className="pt-3 first:pt-0 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <img src={item.productImage} alt="" className="w-12 h-14 rounded-xl object-cover bg-zinc-900 flex-shrink-0" />
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-white truncate">{item.productTitle}</h5>
                            <p className="text-[11px] font-mono text-zinc-500">Qty: {item.quantity} &bull; Size {item.selectedSize}</p>
                          </div>
                        </div>
                        <span className="text-xs font-black font-mono text-amber-400 flex-shrink-0">
                          {(item.price * item.quantity).toLocaleString()} EGP
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-6 border-t border-zinc-900 space-y-2 font-mono text-xs">
                    <div className="flex justify-between text-zinc-400">
                      <span>Subtotal</span>
                      <span>{cartTotal.toLocaleString()} EGP</span>
                    </div>
                    <div className="flex justify-between text-zinc-400">
                      <span>Express Shipment (Cairo/Giza)</span>
                      <span className="text-emerald-400 font-bold">FREE</span>
                    </div>
                    <div className="pt-3 border-t border-zinc-800 flex justify-between text-base font-black text-white">
                      <span>Total Due</span>
                      <span className="text-amber-400 text-xl font-mono">{cartTotal.toLocaleString()} EGP</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-5 px-8 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-xl hover:scale-102"
                  >
                    <span>Proceed To Payment Instructions</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.form>
          )}

          {/* STEP 2: TRANSFER INSTRUCTIONS & UPLOAD VERIFICATION ID */}
          {step === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="max-w-3xl mx-auto bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-12 shadow-2xl space-y-8"
            >
              <div className="text-center space-y-3">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold uppercase tracking-widest">
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Step 2: Instant Transfer Execution</span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  Transfer <span className="text-amber-500 font-mono">{cartTotal.toLocaleString()} EGP</span> via {paymentMethod}
                </h2>
                <p className="text-zinc-400 text-sm leading-relaxed max-w-xl mx-auto">
                  Please complete your instant transfer right now using your phone wallet or banking application.
                </p>
              </div>

              {/* Verified Merchant Copy Box */}
              <div className="bg-gradient-to-r from-zinc-900 via-zinc-850 to-zinc-900 p-6 sm:p-8 rounded-2xl border border-zinc-800 text-center space-y-4">
                <p className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-widest">
                  Official Elfiky_Store Verified {paymentMethod} Line:
                </p>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-2xl sm:text-4xl font-black font-mono tracking-wider text-white select-all">
                    {currentMerchant.phone}
                  </span>
                  <button
                    onClick={() => handleCopyMerchant(currentMerchant.phone)}
                    className="p-3 bg-amber-500 hover:bg-amber-400 text-black rounded-xl font-bold transition-all flex items-center gap-1.5 shadow"
                    title="Copy to clipboard"
                  >
                    {copied ? <Check className="w-5 h-5 animate-bounce" /> : <Copy className="w-5 h-5" />}
                    <span className="text-xs uppercase font-mono">{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                {paymentMethod !== 'InstaPay' && (
                  <p className="text-xs text-amber-400 font-mono">
                    💡 Quick USSD Code: Dial <strong className="text-white">{currentMerchant.code}{cartTotal}#</strong>
                  </p>
                )}
                {paymentMethod === 'InstaPay' && (
                  <p className="text-xs text-blue-400 font-mono">
                    💡 You can transfer instantly from any Egyptian bank account to our InstaPay handle above.
                  </p>
                )}
              </div>

              {/* Form to submit Verification Receipt ID */}
              <form onSubmit={handleFinalOrderSubmit} className="space-y-6 pt-4 border-t border-zinc-900">
                <div className="space-y-2">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-white font-mono">
                    Payment Verification Details
                  </h4>
                  <p className="text-xs text-zinc-500 leading-relaxed font-sans">
                    Once you have sent the transfer, enter the mobile number or InstaPay username you paid from and the exact transaction receipt ID so our automated financial core can approve your shipment.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">
                      Your Transfer Phone / InstaPay Handle
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 01068750578 or @karim_insta"
                      value={paymentPhoneOrInsta}
                      onChange={(e) => setPaymentPhoneOrInsta(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-400 mb-1.5">
                      Transaction Receipt / Reference ID
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 9841029310"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-6 py-4 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-bold uppercase font-mono transition-colors"
                  >
                    &larr; Back
                  </button>

                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-4 px-8 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-2xl"
                  >
                    {loading ? (
                      <>
                        <span className="w-5 h-5 rounded-full border-2 border-black border-t-transparent animate-spin"></span>
                        <span>Verifying Ledger Core...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-5 h-5" />
                        <span>Confirm Instant Payment Receipt</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

            </motion.div>
          )}

          {/* STEP 3: SUCCESS CELEBRATION & UNIQUE ORDER DISPATCH */}
          {step === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-3xl mx-auto bg-zinc-950 border border-amber-500/40 rounded-3xl p-8 sm:p-16 shadow-2xl text-center space-y-8 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-emerald-500 to-amber-500 text-black flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/30">
                <Check className="w-12 h-12 stroke-[3]" />
              </div>

              <div className="space-y-3">
                <span className="px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-black uppercase tracking-widest">
                  Payment Verified Successfully
                </span>
                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
                  Thank You, {customerName}!
                </h1>
                <p className="text-zinc-300 text-base leading-relaxed max-w-xl mx-auto">
                  Your luxury streetwear order has been officially registered in our fulfillment dispatch. Our master ateliers in Cairo are preparing your Giza cotton pieces right now.
                </p>
              </div>

              {/* Order Credential Pill */}
              <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 max-w-md mx-auto flex flex-col items-center gap-2">
                <span className="text-xs text-zinc-400 font-mono uppercase tracking-widest">Master Order Number:</span>
                <span className="text-3xl font-black font-mono text-amber-400 select-all">{confirmedOrderNum}</span>
                <span className="text-xs text-zinc-500 font-mono">Paid via {paymentMethod} (Ref: #{transactionId})</span>
              </div>

              <div className="pt-6 flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  href={`/track?order=${confirmedOrderNum}`}
                  className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black px-10 py-5 rounded-2xl flex items-center justify-center gap-2 text-xs uppercase tracking-widest shadow-xl transition-all hover:scale-105"
                >
                  <span>Track Your Master Shipment</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <Link
                  href="/collections"
                  className="w-full sm:w-auto bg-zinc-900 hover:bg-zinc-800 text-white font-bold px-8 py-5 rounded-2xl text-xs uppercase tracking-widest border border-zinc-800 transition-all hover:scale-105"
                >
                  Continue Shopping
                </Link>
              </div>

            </motion.div>
          )}

        </AnimatePresence>

      </div>
    </div>
  );
}
