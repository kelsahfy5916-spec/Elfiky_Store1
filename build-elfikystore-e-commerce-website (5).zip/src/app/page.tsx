import React from 'react';
import Link from 'next/link';
import { getProductsFilter, getAllVideos, seedDatabase } from '@/app/actions';
import ProductCard from '@/components/ProductCard';
import VideoCard from '@/components/VideoCard';
import MasterProductFilter from '@/components/MasterProductFilter';
import { Sparkles, ArrowRight, ShieldCheck, Flame, Zap, Award, Gem, Play, Sliders, ShoppingBag } from 'lucide-react';

export const revalidate = 0; // Ensures fresh products always

export default async function HomePage() {
  let products = await getProductsFilter();
  let videos = await getAllVideos();

  // Automatic Self-Seeding for absolute flawless reliability
  if (products.length === 0) {
    await seedDatabase();
    products = await getProductsFilter();
    videos = await getAllVideos();
  }

  const featuredProducts = products.filter(p => p.featured).slice(0, 4);
  const newArrivals = products.filter(p => p.newArrival).slice(0, 4);
  const bannerVideos = videos.slice(0, 2);

  return (
    <div className="min-h-screen bg-black text-white font-sans overflow-hidden">
      
      {/* 1. STUNNING ANIMATED HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center justify-center pt-12 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gradient-to-b from-zinc-950 via-black to-zinc-950">
        {/* Absolute Architectural Light Glare */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] max-w-5xl bg-gradient-to-tr from-amber-500/10 via-amber-600/5 to-transparent rounded-full blur-[140px] pointer-events-none"></div>
        <div className="absolute top-1/4 left-10 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none animate-pulse"></div>

        <div className="relative z-10 max-w-6xl mx-auto text-center flex flex-col items-center">
          
          {/* Top Luxurious Collection Tag */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900/90 border border-amber-500/30 text-amber-400 text-xs font-mono uppercase tracking-widest shadow-2xl mb-8">
            <Sparkles className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
            <span>Elfiky_Store • 2026 Advanced Flagship Collection</span>
          </div>

          {/* Master Brand Headline */}
          <h1 className="font-black tracking-tighter text-5xl sm:text-7xl md:text-8xl lg:text-9xl uppercase text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-zinc-500 max-w-5xl">
            Advanced <span className="font-serif italic text-amber-500 font-normal">Luxury</span> Streetwear
          </h1>

          <p className="mt-8 text-zinc-400 text-base sm:text-xl max-w-2xl font-light leading-relaxed">
            Engineered in Cairo. Impeccable 100% Giza Egyptian cotton meets futuristic weather-proof technical outerwear.
          </p>

          {/* CTA Group Buttons */}
          <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md">
            <Link
              href="/collections"
              className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black px-10 py-5 rounded-full flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-2xl shadow-amber-500/25 hover:scale-105 flex-shrink-0"
            >
              <span>Explore Advanced Drops</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            
            <Link
              href="/showcase"
              className="w-full sm:w-auto bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-800 hover:border-zinc-700 font-bold px-8 py-5 rounded-full flex items-center justify-center gap-2 uppercase tracking-wider text-sm transition-all flex-shrink-0 hover:scale-105"
            >
              <Play className="w-4 h-4 fill-white text-white" />
              <span>Watch Brand Explainer</span>
            </Link>
          </div>

          {/* Payment & Craftmanship Icons Pills */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl w-full text-zinc-400 font-mono text-xs">
            <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex items-center justify-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Instant Cash Gateways</span>
            </div>
            <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex items-center justify-center gap-2">
              <Gem className="w-4 h-4 text-amber-500" />
              <span>100% Giza Cotton</span>
            </div>
            <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex items-center justify-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span>Lifetime Warranty</span>
            </div>
            <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex items-center justify-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <span>Drop Shoulder Fit</span>
            </div>
          </div>

        </div>
      </section>

      {/* 2. LIVE INTERACTIVE CATALOG MASTER FILTER SECTION */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-zinc-900">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-widest text-amber-500">
              <Sliders className="w-4 h-4" />
              <span>Complete Master Inventory ({products.length} Drops)</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-2">
              Filter All Live Apparel & Prices
            </h2>
          </div>
          <Link
            href="/collections"
            className="text-amber-500 hover:text-amber-400 font-mono text-sm flex items-center gap-2 font-bold group"
          >
            <span>Open Dedicated Archive Suite</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Dynamic Multi-Criteria Live Filter Engine */}
        <MasterProductFilter initialProducts={products} />
      </section>

      {/* 2.5 CINEMATIC APPARELS SHOWCASE CARD & BUTTON (Exactly like Videos but for Clothes) */}
      <section className="py-24 bg-gradient-to-b from-zinc-950 via-zinc-900/40 to-zinc-950 border-t border-zinc-900 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl text-center mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-black uppercase tracking-widest">
              <ShoppingBag className="w-4 h-4 animate-bounce" />
              <span>Immersive Apparels Portal</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-3">
              The Elfiky Clothes Hub
            </h2>
            <p className="mt-4 text-zinc-400 text-base leading-relaxed font-light">
              Click the flagship apparel showcase card below to immediately enter our complete immersive garment repository. Explore full high-streetwear lines, detailed pricing, and instant size configurations.
            </p>
          </div>

          {/* Majestic Interactive Feature Banner Card for Apparels */}
          <Link href="/collections" className="group block relative bg-zinc-950 border border-zinc-800 hover:border-amber-500/80 rounded-3xl overflow-hidden shadow-2xl transition-all hover:scale-[1.01]">
            <div className="aspect-[21/9] bg-zinc-900 relative overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1600&q=80"
                alt="Elfiky Premium Clothes Hub"
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>

              <span className="absolute top-6 left-6 bg-gradient-to-r from-amber-500 to-amber-600 text-black text-xs font-mono font-black px-4 py-1.5 rounded-full uppercase tracking-wider shadow-xl">
                ★ 100% Immersive Garment Repository
              </span>

              <span className="absolute top-6 right-6 bg-black/80 backdrop-blur-md text-emerald-400 text-xs font-mono font-black px-4 py-1.5 rounded-full border border-zinc-700 shadow-lg">
                17 Advanced Premium Collections Ready
              </span>

              {/* Center Portal Action Overlay Button (Matching the play button of videos) */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex items-center gap-3 px-8 py-5 rounded-2xl bg-amber-500/90 group-hover:bg-amber-400 text-black font-black uppercase tracking-widest text-sm shadow-2xl group-hover:scale-110 transition-all">
                  <ShoppingBag className="w-6 h-6 stroke-[2.5]" />
                  <span>Enter To Inspect More Clothes &rarr;</span>
                </div>
              </div>

              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-zinc-300 font-mono text-xs">
                <span className="text-white font-bold tracking-wide">Featured Categories: Shirts, T-Shirts, Shorts, Pants, Shoes, & Accessories</span>
                <span className="text-amber-400 font-bold hidden sm:inline">Tap to unroll all drops</span>
              </div>
            </div>
          </Link>

          {/* High-End Direct Enter Button Helper */}
          <div className="mt-12 text-center">
            <Link
              href="/collections"
              className="inline-flex items-center gap-3 text-base font-black text-black hover:bg-amber-400 py-5 px-12 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 shadow-2xl shadow-amber-500/20 hover:scale-105 transition-all uppercase tracking-widest flex-shrink-0"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Explore Entire Elfiky Premium Apparels Book</span>
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* 3. BRAND ETHOS & EXPLORER VIDEO CARDS */}
      <section className="py-24 bg-gradient-to-b from-zinc-950 via-zinc-900/30 to-zinc-950 border-y border-zinc-900 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl text-center mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono uppercase tracking-widest">
              <Award className="w-3.5 h-3.5" />
              <span>The Visual Master Guide</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-3">
              Explainers & Runway Campaigns
            </h2>
            <p className="mt-4 text-zinc-400 text-base leading-relaxed font-light">
              Dive deep into the unparalleled architecture of Elfiky_Store. From Giza Egyptian cotton cultivation to our cyberpunk runway presentations in Cairo.
            </p>
          </div>

          {/* Videos Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {bannerVideos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              href="/showcase"
              className="inline-flex items-center gap-2 text-sm font-mono font-bold text-amber-400 hover:text-amber-300 py-2 px-6 rounded-full bg-zinc-900 border border-zinc-800 transition-all hover:scale-105"
            >
              <span>Explore Complete Elfiky Video Library</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 4. NEW ARRIVALS CAROUSEL / GRID */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-b border-zinc-900">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-widest text-emerald-400">
              <Sparkles className="w-4 h-4" />
              <span>Fresh For 2026</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-2">
              New Season Arrivals
            </h2>
          </div>
          <Link
            href="/collections?category=All"
            className="text-amber-500 hover:text-amber-400 font-mono text-sm flex items-center gap-2 font-bold"
          >
            <span>Filter By Category</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {newArrivals.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* 5. INTERACTIVE EGYPTIAN PAYMENTS & AI HIGHLIGHT BANNER */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        <div className="bg-gradient-to-r from-zinc-900 via-zinc-800/80 to-zinc-900 rounded-3xl p-10 md:p-20 border border-zinc-800 relative overflow-hidden">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
              Flawless Egyptian Sizing & Secure Mobile Checkout
            </h2>
            <p className="text-zinc-300 text-base md:text-lg font-light leading-relaxed">
              We empower our clients with the **Elfiky Master AI Sizing Core** to calculate precise fits. When you are ready to complete your purchase, enjoy lightning-fast instant payment processing via:
            </p>

            <div className="flex flex-wrap justify-center gap-4 pt-2">
              <span className="px-5 py-2.5 rounded-2xl bg-red-600 font-mono font-black text-white text-xs tracking-wider shadow-lg">
                🔴 Vodafone Cash
              </span>
              <span className="px-5 py-2.5 rounded-2xl bg-emerald-600 font-mono font-black text-white text-xs tracking-wider shadow-lg">
                🟢 Etisalat Cash
              </span>
              <span className="px-5 py-2.5 rounded-2xl bg-orange-600 font-mono font-black text-white text-xs tracking-wider shadow-lg">
                🟠 Orange Cash
              </span>
              <span className="px-5 py-2.5 rounded-2xl bg-purple-600 font-mono font-black text-white text-xs tracking-wider shadow-lg">
                🟣 We Cash
              </span>
              <span className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 font-mono font-black text-white text-xs tracking-wider shadow-lg">
                ⚡ InstaPay Network
              </span>
            </div>

            <div className="pt-6 flex flex-col sm:flex-row justify-center items-center gap-4">
              <Link
                href="/ai-stylist"
                className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 text-black font-black px-10 py-5 rounded-full text-xs uppercase tracking-widest transition-all shadow-xl hover:scale-105"
              >
                Open Virtual AI Stylist
              </Link>
              <Link
                href="/contact"
                className="w-full sm:w-auto bg-zinc-950 hover:bg-zinc-900 text-white font-bold px-8 py-5 rounded-full text-xs uppercase tracking-widest border border-zinc-800 transition-all hover:scale-105"
              >
                Contact Human Ateliers
              </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
