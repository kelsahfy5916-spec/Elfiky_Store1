'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Play, X, Sparkles, Clock, Film, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function VideoCard({ video }: { video: any }) {
  const router = useRouter();
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <>
      {/* Video Thumbnail Card */}
      <motion.div
        whileHover={{ y: -6 }}
        transition={{ duration: 0.2 }}
        onClick={() => setIsPlaying(true)}
        className="group relative bg-zinc-950 border border-zinc-900 hover:border-zinc-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl cursor-pointer transition-all"
      >
        <div className="aspect-[16/10] bg-zinc-900 overflow-hidden relative">
          <img
            src={video.thumbnailUrl}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90 group-hover:opacity-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

          {/* Featured Badge */}
          {video.featured && (
            <span className="absolute top-4 left-4 bg-amber-500 text-black text-[10px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-wider shadow">
              Cinematic Ethos
            </span>
          )}

          <span className="absolute top-4 right-4 bg-black/70 backdrop-blur-md text-zinc-300 text-xs font-mono font-bold px-3 py-1 rounded-full flex items-center gap-1.5 border border-zinc-800">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            {video.duration || '2:30'}
          </span>

          {/* Center Royal Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-amber-500/90 group-hover:bg-amber-400 text-black flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all">
              <Play className="w-7 h-7 fill-black ml-1" />
            </div>
          </div>
        </div>

        {/* Info Text */}
        <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-500 font-bold uppercase tracking-widest">
              <Film className="w-3.5 h-3.5" />
              <span>{video.category}</span>
            </div>
            <h3 className="font-black text-white text-lg tracking-tight mt-1.5 group-hover:text-amber-400 transition-colors line-clamp-1">
              {video.title}
            </h3>
            <p className="text-zinc-400 text-xs leading-relaxed mt-2 line-clamp-2 font-sans">
              {video.description}
            </p>
          </div>

          <div className="pt-3 border-t border-zinc-900 flex items-center justify-between text-xs font-mono font-bold text-zinc-300 group-hover:text-white">
            <span className="flex items-center gap-1 text-amber-400">
              <Sparkles className="w-3.5 h-3.5" /> Watch Explainer Reel
            </span>
            <span>&rarr;</span>
          </div>
        </div>
      </motion.div>

      {/* Magnificent Playable Video Modal */}
      <AnimatePresence>
        {isPlaying && (
          <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-center p-4 md:p-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPlaying(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-lg"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-zinc-950 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col z-10"
            >
              {/* Top Modal Header */}
              <div className="p-4 md:p-6 bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-500 rounded-xl text-black">
                    <Film className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-white text-base md:text-lg tracking-tight">{video.title}</h3>
                    <p className="text-xs text-amber-400 font-mono tracking-widest uppercase">{video.category}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPlaying(false)}
                  className="p-2.5 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Video Screen */}
              <div className="aspect-video bg-black relative">
                {video.videoUrl.includes('youtube') || video.videoUrl.includes('youtu.be') ? (
                  <iframe
                    src={video.videoUrl}
                    title={video.title}
                    className="w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <video
                    src={video.videoUrl}
                    poster={video.thumbnailUrl}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  >
                    Your master browser does not support the premium Elfiky video engine.
                  </video>
                )}
              </div>

              {/* Bottom Explainer & Shop Button */}
              <div className="p-6 bg-zinc-900 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p className="text-zinc-300 text-sm max-w-2xl leading-relaxed">
                  {video.description}
                </p>
                <button
                  onClick={() => {
                    setIsPlaying(false);
                    router.push('/collections');
                  }}
                  className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 text-black font-black px-6 py-3.5 rounded-2xl flex items-center justify-center gap-2 text-xs uppercase tracking-widest transition-all shadow-xl flex-shrink-0 hover:scale-105"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Shop Pieces in Video</span>
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
