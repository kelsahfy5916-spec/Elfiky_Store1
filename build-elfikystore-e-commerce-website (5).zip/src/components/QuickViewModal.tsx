'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Star, ShoppingBag, Check, ShieldCheck, Sparkles, RefreshCw, Truck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function QuickViewModal() {
  const { quickViewProduct, setQuickViewProduct, addToCart } = useApp();
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [addedAnim, setAddedAnim] = useState(false);

  if (!quickViewProduct) return null;

  const currentSize = selectedSize || quickViewProduct.sizes[0] || 'M';
  const currentColor = selectedColor || quickViewProduct.colors[0] || 'Black';

  const handleAddToCart = () => {
    addToCart(quickViewProduct, currentSize, currentColor, 1);
    setAddedAnim(true);
    setTimeout(() => {
      setAddedAnim(false);
      setQuickViewProduct(null);
    }, 800);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setQuickViewProduct(null)}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <div className="min-h-screen px-4 text-center flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="inline-block w-full max-w-4xl bg-zinc-950 border border-zinc-800 text-left align-middle transition-all rounded-3xl shadow-2xl overflow-hidden my-8 relative"
          >
            {/* Close Button */}
            <button
              onClick={() => setQuickViewProduct(null)}
              className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 hover:text-white backdrop-blur-sm transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-2">
              
              {/* Left Image Gallery */}
              <div className="p-6 lg:p-8 flex flex-col justify-between bg-zinc-900/40">
                <div className="aspect-square sm:aspect-[4/5] max-h-[50vh] sm:max-h-none rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 shadow-inner relative group">
                  <img
                    src={quickViewProduct.images[activeImageIdx] || quickViewProduct.images[0]}
                    alt={quickViewProduct.title}
                    className="w-full h-full object-contain sm:object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  {quickViewProduct.newArrival && (
                    <span className="absolute top-4 left-4 bg-amber-500 text-black text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-md">
                      New Season
                    </span>
                  )}
                </div>

                {/* Thumbnails */}
                {quickViewProduct.images.length > 1 && (
                  <div className="flex gap-3 mt-4 overflow-x-auto pb-2">
                    {quickViewProduct.images.map((img: string, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => setActiveImageIdx(idx)}
                        className={`w-16 h-20 rounded-xl overflow-hidden border-2 transition-all flex-shrink-0 ${
                          activeImageIdx === idx ? 'border-amber-500 scale-105' : 'border-zinc-800 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={img} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Specifications & Buy Area */}
              <div className="p-6 lg:p-8 flex flex-col justify-between space-y-6">
                
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-amber-500 font-bold">
                    <span>{quickViewProduct.category}</span>
                    <span>•</span>
                    <span>{quickViewProduct.gender} Collection</span>
                  </div>

                  <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight mt-1">
                    {quickViewProduct.title}
                  </h2>

                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center gap-1 text-amber-400">
                      <Star className="w-4 h-4 fill-amber-400" />
                      <span className="font-bold text-sm font-mono">{quickViewProduct.rating}</span>
                      <span className="text-zinc-500 text-xs">({quickViewProduct.reviewCount} master reviews)</span>
                    </div>

                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono">
                      <Check className="w-3.5 h-3.5" />
                      <span>In Stock ({quickViewProduct.stock} remaining)</span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-baseline gap-3">
                    <span className="text-3xl font-black font-mono text-amber-400">
                      {quickViewProduct.price.toLocaleString()} EGP
                    </span>
                    {quickViewProduct.originalPrice && (
                      <span className="text-base font-bold font-mono text-zinc-500 line-through">
                        {quickViewProduct.originalPrice.toLocaleString()} EGP
                      </span>
                    )}
                  </div>

                  <p className="mt-4 text-zinc-300 text-sm leading-relaxed pb-4 border-b border-zinc-800">
                    {quickViewProduct.description}
                  </p>
                </div>

                {/* Selections */}
                <div className="space-y-4">
                  {/* Select Size */}
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono">
                        Select Size: <span className="text-amber-400">{currentSize}</span>
                      </label>
                      <button
                        onClick={() => {
                          setQuickViewProduct(null);
                          // Open AI Advisor or route
                        }}
                        className="text-[11px] text-amber-400 hover:underline flex items-center gap-1 font-mono"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Not sure? Ask AI</span>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2.5">
                      {quickViewProduct.sizes.map((sz: string) => (
                        <button
                          key={sz}
                          onClick={() => setSelectedSize(sz)}
                          className={`w-12 h-12 rounded-xl font-mono text-xs font-black transition-all flex items-center justify-center border ${
                            currentSize === sz
                              ? 'bg-amber-500 text-black border-amber-400 scale-105 shadow-lg shadow-amber-500/20'
                              : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800'
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Select Color */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono mb-2">
                      Select Master Color: <span className="text-white">{currentColor}</span>
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {quickViewProduct.colors.map((clr: string) => (
                        <button
                          key={clr}
                          onClick={() => setSelectedColor(clr)}
                          className={`px-4 py-2 rounded-xl font-mono text-xs font-bold transition-all border ${
                            currentColor === clr
                              ? 'bg-white text-black border-white shadow-md'
                              : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-700 hover:text-white'
                          }`}
                        >
                          {clr}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions Button */}
                <div className="pt-4 border-t border-zinc-800 space-y-3">
                  <button
                    onClick={handleAddToCart}
                    disabled={addedAnim}
                    className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-4 px-8 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-xl hover:shadow-amber-500/25 hover:scale-[1.02]"
                  >
                    {addedAnim ? (
                      <>
                        <Check className="w-5 h-5 animate-bounce" />
                        <span>Added to Master Basket!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-5 h-5" />
                        <span>Add to Basket ({quickViewProduct.price.toLocaleString()} EGP)</span>
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-around text-[11px] text-zinc-400 font-mono pt-2">
                    <span className="flex items-center gap-1.5"><Truck className="w-3.5 h-3.5 text-amber-500" /> Free Shipping &gt;2k EGP</span>
                    <span className="flex items-center gap-1.5"><RefreshCw className="w-3.5 h-3.5 text-amber-500" /> 14 Days Easy Exchange</span>
                    <span className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-amber-500" /> 100% Giza Cotton</span>
                  </div>
                </div>

              </div>

            </div>
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
}
