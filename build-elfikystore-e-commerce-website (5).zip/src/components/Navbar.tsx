'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { ShoppingBag, User, Shield, Sparkles, Menu, X, ChevronDown, PhoneCall, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar() {
  const { user, cartCount, setIsCartOpen, setIsAiChatOpen, logout } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);

  const isAdmin = user?.role === 'admin';

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Collections', href: '/collections' },
    { name: 'Brand Showcase', href: '/showcase' },
    { name: 'AI Stylist & Sizing', href: '/ai-stylist' },
    { name: 'Track Order', href: '/track' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-black/90 backdrop-blur-md border-b border-zinc-800 text-white transition-all">
      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-md text-zinc-300 hover:text-white hover:bg-zinc-800 focus:outline-none"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Luxury Brand Logo */}
          <div className="flex-shrink-0 flex items-center min-w-0 pr-2">
            <Link href="/" className="group flex items-center gap-1.5 sm:gap-2 font-black tracking-tighter text-lg sm:text-2xl md:text-3xl truncate font-sans">
              <span className="tracking-widest uppercase truncate">Elfiky_Store</span>
              <span className="inline-block w-2 h-2 rounded-full bg-amber-500 group-hover:scale-150 transition-transform flex-shrink-0"></span>
            </Link>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`relative text-sm font-medium tracking-wide transition-colors py-2 ${
                    isActive ? 'text-amber-400 font-semibold' : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {link.name}
                  {isActive && (
                    <motion.div
                      layoutId="underline"
                      className="absolute left-0 bottom-0 w-full h-0.5 bg-amber-400"
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right End Actions */}
          <div className="flex items-center space-x-1 sm:space-x-4 flex-shrink-0">
            {/* Quick Home CTA Button */}
            <Link
              href="/"
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-200 hover:text-amber-400 hover:border-zinc-700 transition-all text-xs font-bold uppercase tracking-wider shadow hover:scale-105 flex-shrink-0"
              title="Storefront Home"
            >
              <span className="text-amber-500 text-sm">🏠</span>
              <span className="hidden sm:inline">Home</span>
            </Link>

            {/* AI Advisor Button */}
            <button
              onClick={() => setIsAiChatOpen(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 text-xs font-bold tracking-wider uppercase transition-all shadow-lg shadow-amber-500/5 hover:scale-105"
            >
              <Sparkles className="w-4 h-4 animate-spin" style={{ animationDuration: '4s' }} />
              <span>Ask AI Stylist</span>
            </button>

            {/* Shopping Basket Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-full bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-200 hover:text-amber-400 transition-colors group focus:outline-none"
              title="Shopping Basket"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
              {cartCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-amber-500 text-black text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-md"
                >
                  {cartCount}
                </motion.span>
              )}
            </button>

            {/* User Account / Admin Area */}
            <div className="relative">
              {user ? (
                <div>
                  <button
                    onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                    className="flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-sm font-medium hover:bg-zinc-800 transition-colors focus:outline-none"
                  >
                    {isAdmin ? (
                      <Shield className="w-4 h-4 text-amber-500" />
                    ) : (
                      <User className="w-4 h-4 text-amber-400" />
                    )}
                    <span className="hidden md:inline font-mono text-xs font-bold truncate max-w-[120px]">
                      {user.name.split(' ')[0]}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
                  </button>

                  <AnimatePresence>
                    {isUserDropdownOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-3 w-64 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl py-2 z-50 text-white divide-y divide-zinc-800"
                      >
                        <div className="px-4 py-3">
                          <p className="text-xs text-zinc-400 uppercase tracking-wider">Signed in as</p>
                          <p className="text-sm font-bold truncate">{user.email}</p>
                          <span className={`inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            isAdmin ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}>
                            <CheckCircle className="w-3 h-3" />
                            {user.role} account
                          </span>
                        </div>

                        {isAdmin && (
                          <div className="py-1">
                            <Link
                              href="/admin"
                              onClick={() => setIsUserDropdownOpen(false)}
                              className="flex items-center gap-3 px-4 py-2.5 text-sm font-bold text-amber-400 hover:bg-zinc-800/80 transition-colors"
                            >
                              <Shield className="w-4 h-4" />
                              <span>Master Admin Control Panel</span>
                            </Link>
                          </div>
                        )}

                        <div className="py-1">
                          <Link
                            href="/track"
                            onClick={() => setIsUserDropdownOpen(false)}
                            className="flex items-center gap-3 px-4 py-2 text-sm text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
                          >
                            <ShoppingBag className="w-4 h-4 text-zinc-400" />
                            <span>My Orders</span>
                          </Link>
                          <Link
                            href="/contact"
                            onClick={() => setIsUserDropdownOpen(false)}
                            className="flex items-center gap-3 px-4 py-2 text-sm text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
                          >
                            <PhoneCall className="w-4 h-4 text-zinc-400" />
                            <span>Customer Care</span>
                          </Link>
                        </div>

                        <div className="py-1">
                          <button
                            onClick={() => {
                              logout();
                              setIsUserDropdownOpen(false);
                              router.push('/login');
                            }}
                            className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                          >
                            Sign out
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  href="/login"
                  className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wider transition-all shadow-lg hover:shadow-amber-500/25 hover:scale-105"
                >
                  <User className="w-4 h-4" />
                  <span>Login / Admin</span>
                </Link>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden bg-zinc-950 border-b border-zinc-800 px-4 pt-2 pb-6 space-y-3 overflow-hidden"
          >
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`block px-4 py-3 rounded-lg text-base font-medium transition-colors ${
                  pathname === link.href ? 'bg-amber-500 text-black font-bold' : 'text-zinc-300 hover:bg-zinc-900'
                }`}
              >
                {link.name}
              </Link>
            ))}

            <div className="pt-4 border-t border-zinc-800 flex items-center justify-between px-2">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsAiChatOpen(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ask AI Stylist</span>
              </button>
              
              {!user && (
                <Link
                  href="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-2 bg-amber-500 text-black px-4 py-2.5 rounded-lg font-bold text-xs uppercase tracking-wider"
                >
                  <User className="w-4 h-4" />
                  <span>Login Base</span>
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
