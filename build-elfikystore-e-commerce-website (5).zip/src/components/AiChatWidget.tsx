'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { askElfikyAi } from '@/app/actions/aiAdvisor';
import { Sparkles, X, Send, Bot, User, ArrowRight, CornerDownLeft, Star, ShoppingBag, Ruler } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  products?: any[];
}

export default function AiChatWidget() {
  const { isAiChatOpen, setIsAiChatOpen, setQuickViewProduct } = useApp();
  const router = useRouter();
  const [inputQuery, setInputQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      text: "✨ **Greetings! I am the Elfiky Master AI Stylist & Size Advisor.**\n\nI am engineered with detailed sizing formulas for our European drop-shoulder fits and premium Giza cotton pieces. Tell me your exact **Height & Weight** (e.g., '180cm 78kg') or ask for personalized streetwear recommendations!",
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isAiChatOpen) {
      scrollToBottom();
    }
  }, [isAiChatOpen, messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputQuery.trim() || isLoading) return;

    const queryCopy = inputQuery.trim();
    setInputQuery('');

    // Add user message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: queryCopy,
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const response = await askElfikyAi(queryCopy);
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: response.answer,
        products: response.products,
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: `ai-err-${Date.now()}`,
        sender: 'ai',
        text: "I am having trouble processing your styling request at the moment. Please consult our human care team!",
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (promptText: string) => {
    setInputQuery(promptText);
  };

  return (
    <>
      {/* Floating Trigger Icon */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {!isAiChatOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.1, rotate: 12 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsAiChatOpen(true)}
            className="group relative bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-black p-4 rounded-full shadow-2xl flex items-center justify-center border-2 border-amber-300 focus:outline-none"
            title="Open Elfiky AI Stylist"
          >
            <span className="absolute -top-3 -left-3 bg-black text-amber-400 border border-amber-500/40 text-[10px] font-mono font-black px-2.5 py-0.5 rounded-full shadow-lg animate-pulse uppercase">
              AI Stylist
            </span>
            <Sparkles className="w-7 h-7 text-black animate-spin" style={{ animationDuration: '7s' }} />
          </motion.button>
        )}
      </div>

      {/* Main Chat Box Modal */}
      <AnimatePresence>
        {isAiChatOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-center p-4 sm:p-6 md:p-10">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAiChatOpen(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Chat Dialog Window */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl h-[92vh] sm:h-[85vh] max-h-[800px] bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden z-10"
            >
              {/* Header */}
              <div className="p-5 bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 text-black flex items-center justify-center shadow-lg">
                    <Bot className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-black text-white text-base tracking-tight flex items-center gap-1.5">
                      <span>Elfiky Master AI Advisor</span>
                      <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    </h3>
                    <p className="text-xs text-zinc-400 font-mono">Calculates exact size formulas & instant styling</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsAiChatOpen(false)}
                  className="p-2 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Message Feed */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
                {messages.map((m) => (
                  <motion.div
                    key={m.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-start gap-3 max-w-[90%]">
                      {m.sender === 'ai' && (
                        <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center flex-shrink-0 mt-1">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}

                      <div className={`p-4 rounded-3xl text-sm leading-relaxed ${
                        m.sender === 'user'
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black font-medium rounded-tr-none'
                          : 'bg-zinc-900 text-zinc-200 border border-zinc-800 rounded-tl-none space-y-3 shadow-inner'
                      }`}>
                        {/* Text Content parsed nicely */}
                        <div className="whitespace-pre-line font-sans">{m.text}</div>

                        {/* Product Match Highlights */}
                        {m.products && m.products.length > 0 && (
                          <div className="pt-3 border-t border-zinc-800 space-y-3">
                            <p className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>AI Featured Matches For You:</span>
                            </p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                              {m.products.map((prod) => (
                                <div
                                  key={prod.id}
                                  onClick={() => {
                                    setIsAiChatOpen(false);
                                    setQuickViewProduct(prod);
                                  }}
                                  className="group p-2.5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-amber-500/50 flex items-center gap-3 cursor-pointer transition-all hover:scale-105"
                                >
                                  <img src={prod.images[0]} alt="" className="w-12 h-14 rounded-xl object-cover flex-shrink-0 bg-zinc-900" />
                                  <div className="flex-1 min-w-0">
                                    <h5 className="text-xs font-bold text-white truncate group-hover:text-amber-400 transition-colors">
                                      {prod.title}
                                    </h5>
                                    <p className="text-[11px] font-mono text-zinc-400 mt-0.5">
                                      {prod.price.toLocaleString()} EGP
                                    </p>
                                  </div>
                                  <ArrowRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors flex-shrink-0" />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {m.sender === 'user' && (
                        <div className="w-8 h-8 rounded-xl bg-zinc-800 text-zinc-300 flex items-center justify-center flex-shrink-0 mt-1">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}

                {isLoading && (
                  <div className="flex items-center gap-3 text-zinc-500 font-mono text-xs">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                      <Bot className="w-4 h-4 animate-spin" />
                    </div>
                    <span>Elfiky Master AI is processing tailoring algorithms...</span>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Prompts Helper */}
              <div className="px-5 py-2.5 bg-zinc-900/50 border-t border-zinc-800 flex items-center gap-2 overflow-x-auto pb-2">
                <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase tracking-widest mr-1 flex-shrink-0 flex items-center gap-1">
                  <Ruler className="w-3 h-3 text-amber-500" /> Examples:
                </span>
                <button
                  onClick={() => handleQuickPrompt("I am 182cm and 82kg, what size hoodie should I buy?")}
                  className="px-3 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono whitespace-nowrap transition-colors"
                >
                  📐 182cm 82kg, what size?
                </button>
                <button
                  onClick={() => handleQuickPrompt("What pieces are made of 100% Giza Egyptian cotton?")}
                  className="px-3 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono whitespace-nowrap transition-colors"
                >
                  🇪🇬 100% Giza Cotton pieces
                </button>
                <button
                  onClick={() => handleQuickPrompt("What are your payment methods with mobile cash?")}
                  className="px-3 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono whitespace-nowrap transition-colors"
                >
                  💳 Vodafone & InstaPay Gateways
                </button>
                <button
                  onClick={() => handleQuickPrompt("Recommend me an elegant Cyberpunk tech outfit")}
                  className="px-3 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono whitespace-nowrap transition-colors"
                >
                  🔥 Cyberpunk tech outfit
                </button>
              </div>

              {/* Input Footer */}
              <form onSubmit={handleSendMessage} className="p-4 bg-zinc-900 border-t border-zinc-800 flex gap-2 items-center">
                <input
                  type="text"
                  placeholder="Ask your query or enter measurements (e.g. 178cm 75kg)..."
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  className="flex-1 bg-zinc-950 border border-zinc-800 text-white px-5 py-3.5 rounded-2xl text-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
                <button
                  type="submit"
                  disabled={!inputQuery.trim() || isLoading}
                  className="bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-black p-3.5 rounded-2xl transition-all flex items-center justify-center flex-shrink-0 shadow-lg hover:scale-105"
                  title="Send message"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
