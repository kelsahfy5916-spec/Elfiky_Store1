'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ShoppingBag, Eye, Star, Check, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ProductCard({ product }: { product: any }) {
  const { setQuickViewProduct, addToCart } = useApp();
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [addedAnim, setAddedAnim] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedSize, product.colors[0] || 'Black', 1);
    setAddedAnim(true);
    setTimeout(() => {
      setAddedAnim(false);
    }, 800);
  };

  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <motion.div
      whileHover={{ y: -6 }}
      transition={{ duration: 0.2 }}
      onClick={() => setQuickViewProduct(product)}
      className="group relative bg-zinc-950 border border-zinc-900 hover:border-zinc-800 rounded-3xl overflow-hidden flex flex-col shadow-xl cursor-pointer transition-all"
    >
      {/* Top Image Box */}
      <div className="aspect-[4/5] bg-zinc-900 overflow-hidden relative">
        {/* Main Img */}
        <img
          src={product.images[0]}
          alt={product.title}
          className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 ${
            product.images[1] ? 'group-hover:opacity-0' : ''
          }`}
        />
        {/* Secondary Img on Hover if present */}
        {product.images[1] && (
          <img
            src={product.images[1]}
            alt={product.title}
            className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-700 group-hover:scale-105"
          />
        )}

        {/* Status Pill Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start z-10">
          {hasDiscount && (
            <span className="bg-gradient-to-r from-red-600 to-amber-600 text-white text-[10px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-wider shadow">
              SAVE {(product.originalPrice - product.price).toLocaleString()} EGP
            </span>
          )}
          {product.newArrival && (
            <span className="bg-amber-500 text-black text-[10px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-wider shadow">
              New Season
            </span>
          )}
        </div>

        {/* Quick View Floating button */}
        <div className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setQuickViewProduct(product);
            }}
            className="p-2.5 rounded-full bg-black/80 hover:bg-black text-white backdrop-blur-sm transition-all hover:scale-110"
            title="Quick View Details"
          >
            <Eye className="w-4 h-4 text-amber-400" />
          </button>
        </div>

        {/* Size Pills On Hover Over Image */}
        <div className="absolute bottom-3 inset-x-3 z-10 flex flex-wrap items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-black/70 backdrop-blur-md p-2 rounded-2xl border border-zinc-800 text-center">
          <span className="text-[10px] font-mono font-bold text-amber-400 w-full block sm:inline sm:w-auto uppercase mr-1">Select Size:</span>
          {product.sizes?.map((sz: string) => (
            <button
              key={sz}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedSize(sz);
              }}
              className={`px-2 py-1 min-w-[24px] rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center ${
                selectedSize === sz ? 'bg-amber-500 text-black font-black scale-110 shadow-lg shadow-amber-500/30' : 'text-zinc-200 hover:text-white hover:bg-zinc-800 bg-zinc-900/80'
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </div>

      {/* Details Box */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          {/* Tag & Rating */}
          <div className="flex items-center justify-between text-xs font-mono text-zinc-400">
            <span className="tracking-widest uppercase text-amber-500/90 font-bold">{product.category}</span>
            <div className="flex items-center gap-1 text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span className="font-bold">{product.rating}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-bold text-white text-base tracking-tight mt-1 group-hover:text-amber-400 transition-colors line-clamp-2">
            {product.title}
          </h3>
        </div>

        {/* Price & Buy Button */}
        <div className="pt-2 border-t border-zinc-900 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-black font-mono text-white tracking-tight">
              {product.price.toLocaleString()} <span className="text-amber-500 text-xs font-sans">EGP</span>
            </span>
            {hasDiscount && (
              <span className="text-xs font-bold font-mono text-zinc-500 line-through">
                {product.originalPrice.toLocaleString()} EGP
              </span>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={addedAnim}
            className={`p-3 rounded-2xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-lg ${
              addedAnim
                ? 'bg-emerald-500 text-black scale-105'
                : 'bg-zinc-900 hover:bg-amber-500 hover:text-black text-zinc-200 border border-zinc-800'
            }`}
            title={`Add ${selectedSize} to Basket`}
          >
            {addedAnim ? (
              <>
                <Check className="w-4 h-4 animate-bounce flex-shrink-0" />
                <span className="font-mono text-[11px]">Added!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4 flex-shrink-0" />
                <span className="font-mono text-[11px]">Add ({selectedSize})</span>
              </>
            )}
          </button>
        </div>
      </div>

    </motion.div>
  );
}
