'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CartDrawer() {
  const { cart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount, isCartOpen, setIsCartOpen } = useApp();
  const router = useRouter();
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    setPromoSuccess('');

    if (promoCode.trim().toUpperCase() === 'ELFIKY10') {
      setDiscount(0.1);
      setPromoSuccess('Promo code ELFIKY10 applied! 10% off.');
    } else if (promoCode.trim().toUpperCase() === 'VIP20') {
      setDiscount(0.2);
      setPromoSuccess('Promo code VIP20 applied! 20% off.');
    } else {
      setPromoError('Invalid promotion code.');
    }
  };

  const finalTotal = Math.round(cartTotal * (1 - discount));

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
          />

          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="pointer-events-auto fixed inset-y-0 right-0 flex max-w-full pl-10">
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 250 }}
                className="w-screen max-w-md bg-zinc-950 border-l border-zinc-800 text-white flex flex-col shadow-2xl"
              >
                {/* Header */}
                <div className="p-6 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-500 rounded-xl text-black">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-lg font-black tracking-wider uppercase">Shopping Basket</h2>
                      <p className="text-xs text-zinc-400 font-mono">{cartCount} items selected</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="p-2 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Body / Items list */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 divide-y divide-zinc-900">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center py-12">
                      <div className="w-20 h-20 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-600 mb-4 border border-zinc-800">
                        <ShoppingBag className="w-10 h-10" />
                      </div>
                      <h3 className="text-lg font-bold text-zinc-300 uppercase tracking-wide">Your basket is empty</h3>
                      <p className="mt-2 text-xs text-zinc-500 max-w-xs leading-relaxed">
                        Explore our advanced streetwear collections and ultra-premium Giza cotton pieces to fill your basket.
                      </p>
                      <button
                        onClick={() => {
                          setIsCartOpen(false);
                          router.push('/collections');
                        }}
                        className="mt-6 bg-amber-500 hover:bg-amber-400 text-black font-black px-6 py-3 rounded-full text-xs uppercase tracking-wider transition-all shadow-lg hover:scale-105"
                      >
                        Explore Collections
                      </button>
                    </div>
                  ) : (
                    cart.map((item) => (
                      <motion.div
                        layout
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        className="pt-4 first:pt-0 flex gap-4 items-start"
                      >
                        {/* Thumbnail */}
                        <div className="w-20 h-24 rounded-xl bg-zinc-900 border border-zinc-800 overflow-hidden flex-shrink-0 relative">
                          {item.productImage ? (
                            <img src={item.productImage} alt={item.productTitle} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-zinc-600">No Img</div>
                          )}
                        </div>

                        {/* Details */}
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold text-white truncate">{item.productTitle}</h4>
                          <div className="mt-1 flex flex-wrap gap-2 text-xs font-mono">
                            <span className="px-2 py-0.5 rounded bg-zinc-900 text-amber-400 border border-zinc-800">
                              Size: {item.selectedSize}
                            </span>
                            <span className="px-2 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">
                              {item.selectedColor}
                            </span>
                          </div>
                          
                          <div className="mt-3 flex items-center justify-between">
                            <div className="flex items-center border border-zinc-800 rounded-lg bg-zinc-900/80">
                              <button
                                onClick={() => updateQuantity(item.id, -1)}
                                className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-l-lg transition-colors"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="px-2.5 font-mono text-xs font-bold">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, 1)}
                                className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-r-lg transition-colors"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <p className="text-sm font-black font-mono text-amber-400">
                              {(item.price * item.quantity).toLocaleString()} EGP
                            </p>
                          </div>
                        </div>

                        {/* Remove button */}
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-1.5 hover:bg-red-500/10 text-zinc-500 hover:text-red-400 rounded-lg transition-colors flex-shrink-0"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </motion.div>
                    ))
                  )}
                </div>

                {/* Footer / Summary */}
                {cart.length > 0 && (
                  <div className="p-6 border-t border-zinc-800 bg-zinc-900/40 space-y-4">
                    
                    {/* Promo Code box */}
                    <form onSubmit={handleApplyPromo} className="flex gap-2">
                      <div className="relative flex-1">
                        <Tag className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="text"
                          placeholder="Promo Code (Try ELFIKY10)"
                          value={promoCode}
                          onChange={(e) => setPromoCode(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white uppercase font-mono focus:outline-none focus:border-amber-500 transition-colors"
                        />
                      </div>
                      <button
                        type="submit"
                        className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold px-4 py-2 rounded-xl text-xs uppercase tracking-wider transition-colors"
                      >
                        Apply
                      </button>
                    </form>
                    {promoError && <p className="text-[11px] font-mono text-red-400 font-bold">{promoError}</p>}
                    {promoSuccess && <p className="text-[11px] font-mono text-emerald-400 font-bold">{promoSuccess}</p>}

                    {/* Cost Calculations */}
                    <div className="space-y-1.5 font-mono text-xs">
                      <div className="flex justify-between text-zinc-400">
                        <span>Subtotal ({cartCount} items)</span>
                        <span>{cartTotal.toLocaleString()} EGP</span>
                      </div>
                      {discount > 0 && (
                        <div className="flex justify-between text-emerald-400 font-bold">
                          <span>VIP Discount ({discount * 100}%)</span>
                          <span>-{(cartTotal - finalTotal).toLocaleString()} EGP</span>
                        </div>
                      )}
                      <div className="flex justify-between text-zinc-400">
                        <span>Verified Express Shipping</span>
                        <span className="text-amber-400 font-bold">FREE</span>
                      </div>
                      <div className="pt-2 border-t border-zinc-800 flex justify-between text-base font-black text-white">
                        <span>Total Due</span>
                        <span className="text-amber-400">{finalTotal.toLocaleString()} EGP</span>
                      </div>
                    </div>

                    {/* Egyptian Wallets Banner */}
                    <div className="flex items-center justify-center gap-1.5 text-[10px] text-zinc-400 bg-zinc-900 py-1.5 rounded-lg border border-zinc-800">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                      <span>Instant Secure Checkout via Vodafone, Etisalat, Orange, We & InstaPay</span>
                    </div>

                    {/* Checkout Button */}
                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        router.push('/checkout');
                      }}
                      className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black py-4 px-6 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-wider text-sm transition-all shadow-xl hover:shadow-amber-500/20 hover:scale-[1.02]"
                    >
                      <span>Proceed to Secure Checkout</span>
                      <ArrowRight className="w-5 h-5" />
                    </button>

                    <button
                      onClick={() => clearCart()}
                      className="w-full text-center text-xs text-zinc-500 hover:text-red-400 pt-1 font-mono transition-colors"
                    >
                      Empty Basket
                    </button>
                  </div>
                )}
              </motion.div>
            </div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
