'use client';

import React from 'react';
import Link from 'next/link';
import { Sparkles, Phone, Mail, MapPin, Camera, Globe, Send } from 'lucide-react';

export default function Footer() {
  const paymentMethods = [
    { name: 'Vodafone Cash', color: 'bg-red-600 text-white' },
    { name: 'Etisalat Cash', color: 'bg-emerald-600 text-white' },
    { name: 'Orange Cash', color: 'bg-orange-600 text-white' },
    { name: 'We Cash', color: 'bg-purple-600 text-white' },
    { name: 'InstaPay Network', color: 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold' },
  ];

  return (
    <footer className="bg-black text-zinc-400 border-t border-zinc-900 pt-16 pb-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Supreme Brand Banner inside Footer */}
        <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 rounded-3xl p-8 md:p-12 border border-zinc-800 mb-16 relative overflow-hidden">
          <div className="absolute top-0 right-0 translate-x-12 -translate-y-12 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="max-w-xl text-center lg:text-left">
              <h3 className="text-2xl md:text-3xl font-black text-white tracking-tight flex items-center justify-center lg:justify-start gap-2">
                <span>The Elfiky_Store Newsletter</span>
                <Sparkles className="w-6 h-6 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
              </h3>
              <p className="mt-2 text-zinc-400 text-sm md:text-base leading-relaxed">
                Subscribe to secure priority access to our limited Giza Cotton drops, private runway invites, and exclusive flash discounts.
              </p>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); alert('Thank you for subscribing to Elfiky_Store Official VIP newsletter!'); }} className="flex w-full lg:w-auto max-w-md gap-2">
              <input
                type="email"
                placeholder="Enter your VIP email..."
                required
                className="bg-zinc-950 border border-zinc-700 text-white px-5 py-3.5 rounded-full w-full focus:outline-none focus:border-amber-500 transition-colors text-sm"
              />
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-black font-black px-6 py-3.5 rounded-full transition-all flex items-center justify-center gap-2 flex-shrink-0 text-xs uppercase tracking-wider shadow-lg hover:scale-105"
              >
                <span>Join VIP</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* 4-Column Directory */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="inline-flex items-center gap-2 font-black tracking-tighter text-3xl text-white">
              <span>Elfiky_Store</span>
            </Link>
            <p className="text-sm text-zinc-400 leading-relaxed max-w-sm">
              The premier advanced luxury fashion & high streetwear house. Engineered with impeccable Giza Egyptian cotton and futuristic outerwear technologies.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-amber-500 hover:text-black flex items-center justify-center text-white transition-all hover:scale-110" title="Brand Visual Studio">
                <Camera className="w-5 h-5" />
              </a>
              <a href="https://elfikystore.com" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-amber-500 hover:text-black flex items-center justify-center text-white transition-all hover:scale-110" title="Global Network">
                <Globe className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-widest uppercase font-mono">Collections</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link href="/collections?category=Hoodies" className="hover:text-amber-400 transition-colors">Royal Velvet Hoodies</Link></li>
              <li><Link href="/collections?category=T-Shirts" className="hover:text-amber-400 transition-colors">Giza Drop-Shoulder Tees</Link></li>
              <li><Link href="/collections?category=Jackets" className="hover:text-amber-400 transition-colors">Cyberpunk Outerwear</Link></li>
              <li><Link href="/collections?category=Trousers" className="hover:text-amber-400 transition-colors">Italian Linen Trousers</Link></li>
              <li><Link href="/collections?category=Accessories" className="hover:text-amber-400 transition-colors">Silk Monogram Scarves</Link></li>
            </ul>
          </div>

          {/* Customer Care */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-widest uppercase font-mono">Customer Care</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link href="/ai-stylist" className="hover:text-amber-400 transition-colors">AI Size Advisor</Link></li>
              <li><Link href="/track" className="hover:text-amber-400 transition-colors">Track Order Status</Link></li>
              <li><Link href="/showcase" className="hover:text-amber-400 transition-colors">Brand Explainer Videos</Link></li>
              <li><Link href="/contact" className="hover:text-amber-400 transition-colors">Contact Our Ateliers</Link></li>
              <li><Link href="/login" className="hover:text-amber-400 transition-colors">Client Account & Admin</Link></li>
            </ul>
          </div>

          {/* Ateliers & Contact */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-widest uppercase font-mono">Ateliers & Headquarters</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3 text-zinc-300">
                <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0 mt-1" />
                <span>Egypt, South Sinai</span>
              </li>
              <li className="flex items-center gap-3 text-zinc-300">
                <Phone className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <span>+20 1068750578</span>
              </li>
              <li className="flex items-center gap-3 text-zinc-300">
                <Mail className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <span>care@elfikystore.com</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Supported Egyptian Payment Gateways */}
        <div className="border-t border-zinc-900 pt-8 pb-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <span className="text-xs uppercase font-mono tracking-widest text-zinc-500 mr-2">Verified Egyptian Instant Payments:</span>
            {paymentMethods.map((pm) => (
              <span key={pm.name} className={`px-3 py-1 rounded-full text-xs font-medium tracking-wide shadow ${pm.color}`}>
                {pm.name}
              </span>
            ))}
          </div>
          <div className="text-xs text-zinc-500 font-mono text-center md:text-right">
            © 2026 Elfiky_Store Official Website. Built for Superior Performance.
          </div>
        </div>

      </div>
    </footer>
  );
}
