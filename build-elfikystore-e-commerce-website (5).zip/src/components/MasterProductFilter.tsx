'use client';

import React, { useState, useMemo } from 'react';
import ProductCard from '@/components/ProductCard';
import { Search, SlidersHorizontal, ArrowUpDown, RefreshCw, Filter, Check, X, Ruler, Plus, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function MasterProductFilter({
  initialProducts,
  initialCategory = 'All',
  initialQuery = '',
}: {
  initialProducts: any[];
  initialCategory?: string;
  initialQuery?: string;
}) {
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [selectedSize, setSelectedSize] = useState('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest' | 'rating'>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);

  // Toggle advanced sizing drawer to maintain an exceptionally clean premium UI
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);

  // Show More display limit
  const [displayLimit, setDisplayLimit] = useState<number>(8);

  // Master Categories
  const categories = useMemo(() => {
    return ['All', 'Shirts', 'T-Shirts', 'Shortes', 'Pants', 'Shoes', 'Accessories'];
  }, []);

  // Sizing scale as requested: 32 up to 4X
  const sizes = useMemo(() => {
    return ['All', '32', '34', '36', '38', '40', '42', '44', 'S', 'M', 'L', 'XL', '2X', '3X', '4X'];
  }, []);

  // Find max price for potential slider or info
  const maxAvailablePrice = useMemo(() => {
    if (initialProducts.length === 0) return 5000;
    return Math.max(...initialProducts.map(p => p.price));
  }, [initialProducts]);

  const [priceLimit, setPriceLimit] = useState<number>(maxAvailablePrice);

  // Perform live multi-criteria filtering
  const filteredProducts = useMemo(() => {
    return initialProducts.filter(p => {
      // 1. Search Query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const titleMatch = p.title?.toLowerCase().includes(q);
        const descMatch = p.description?.toLowerCase().includes(q);
        const catMatch = p.category?.toLowerCase().includes(q);
        const clrMatch = p.colors?.some((c: string) => c.toLowerCase().includes(q));
        if (!titleMatch && !descMatch && !catMatch && !clrMatch) return false;
      }

      // 2. Category
      if (selectedCategory !== 'All' && p.category?.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }

      // 3. Size
      if (selectedSize !== 'All') {
        const hasSizeMatch = p.sizes?.some((sz: string) => sz.toLowerCase() === selectedSize.toLowerCase());
        if (!hasSizeMatch) return false;
      }

      // 4. Price Limit
      if (p.price > priceLimit) {
        return false;
      }

      // 5. In Stock
      if (inStockOnly && p.stock <= 0) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      // Sorting
      if (sortBy === 'featured') {
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      }
      if (sortBy === 'price-asc') {
        return a.price - b.price;
      }
      if (sortBy === 'price-desc') {
        return b.price - a.price;
      }
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === 'rating') {
        return Number(b.rating) - Number(a.rating);
      }
      return 0;
    });
  }, [initialProducts, searchQuery, selectedCategory, selectedSize, priceLimit, inStockOnly, sortBy]);

  // Apply display limit for pristine card organization
  const visibleProducts = useMemo(() => {
    return filteredProducts.slice(0, displayLimit);
  }, [filteredProducts, displayLimit]);

  const hasMore = filteredProducts.length > displayLimit;

  const isAdvancedFiltered = selectedSize !== 'All' || priceLimit < maxAvailablePrice || inStockOnly;
  const isFiltered = searchQuery !== '' || selectedCategory !== 'All' || isAdvancedFiltered;

  const handleResetAll = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedSize('All');
    setPriceLimit(maxAvailablePrice);
    setInStockOnly(false);
    setSortBy('featured');
    setDisplayLimit(8);
  };

  const handleResetAdvanced = () => {
    setSelectedSize('All');
    setPriceLimit(maxAvailablePrice);
    setInStockOnly(false);
  };

  return (
    <div className="space-y-10">
      
      {/* Pristine Minimalist Toolbar Container */}
      <div className="bg-zinc-950/90 border border-zinc-800/80 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md space-y-6">
        
        {/* 1. Horizontal Premium Segmented Categories Pill Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-amber-500 mr-2 flex items-center gap-1.5 flex-shrink-0">
            <SlidersHorizontal className="w-4 h-4" /> Collections:
          </span>
          {categories.map((cat) => {
            const active = selectedCategory.toLowerCase() === cat.toLowerCase();
            return (
              <button
                key={cat}
                onClick={() => { setSelectedCategory(cat); setDisplayLimit(8); }}
                className={`px-5 py-3 rounded-2xl text-xs font-mono font-black whitespace-nowrap transition-all border flex-shrink-0 ${
                  active
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black border-amber-400 shadow-xl scale-105'
                    : 'bg-zinc-900/60 text-zinc-400 border-zinc-800/80 hover:border-zinc-700 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                {cat === 'All' ? '⚡ All Inventory' : cat}
              </button>
            );
          })}
        </div>

        {/* 2. Sleek Search, Sort & Advanced Toggle Toolbar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-4 border-t border-zinc-900/80">
          
          {/* Search Box */}
          <div className="relative flex-1 w-full max-w-xl">
            <Search className="absolute left-4 top-3.5 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Search fabrics, names, codes..."
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setDisplayLimit(8); }}
              className="w-full bg-zinc-900/50 border border-zinc-800/80 text-white pl-11 pr-10 py-3 rounded-xl text-xs focus:outline-none focus:border-amber-500 transition-colors font-sans"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3.5 p-1 text-zinc-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Right Action buttons */}
          <div className="flex flex-wrap items-center justify-end gap-3 w-full md:w-auto flex-shrink-0">
            
            {/* Advanced Filters Button */}
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className={`px-4 py-3 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 border ${
                showAdvanced || isAdvancedFiltered
                  ? 'bg-amber-500/10 border-amber-500/50 text-amber-400 shadow-lg font-black'
                  : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
              }`}
            >
              <Ruler className="w-3.5 h-3.5 text-amber-500" />
              <span>Sizes & Advanced</span>
              {isAdvancedFiltered && (
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
              )}
              {showAdvanced ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {/* Sorting Select */}
            <div className="flex items-center gap-2 bg-zinc-900/80 border border-zinc-800 pl-3 pr-1 py-2 rounded-xl text-xs font-mono">
              <ArrowUpDown className="w-3.5 h-3.5 text-zinc-400" />
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-transparent text-white font-bold focus:outline-none cursor-pointer text-xs"
              >
                <option value="featured">🔥 Featured</option>
                <option value="newest">✨ New Season</option>
                <option value="price-asc">💵 Price: Low &rarr; High</option>
                <option value="price-desc">💰 Price: High &rarr; Low</option>
                <option value="rating">⭐ Top Rated</option>
              </select>
            </div>

          </div>

        </div>

        {/* 3. Advanced Glassmorphic Sizing & Filtering Drawer */}
        <AnimatePresence>
          {showAdvanced && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden border-t border-zinc-800/80 pt-6 space-y-6"
            >
              {/* Sizing Scale Matrix (32 -> 4X) */}
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5" /> Select Exact Size (32 &rarr; 4X):
                  </span>
                  {selectedSize !== 'All' && (
                    <button
                      onClick={() => setSelectedSize('All')}
                      className="text-[11px] font-mono text-zinc-500 hover:text-white"
                    >
                      Clear Size &times;
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((sz) => {
                    const active = selectedSize.toLowerCase() === sz.toLowerCase();
                    return (
                      <button
                        key={sz}
                        onClick={() => { setSelectedSize(sz); setDisplayLimit(8); }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                          active
                            ? 'bg-emerald-500 text-black font-black border-emerald-400 shadow-md scale-105 shadow-emerald-500/10'
                            : 'bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:border-zinc-700 hover:text-white hover:bg-zinc-800/50'
                        }`}
                      >
                        {sz === 'All' ? '⚡ Any Size' : sz}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Secondary Options Row (Price Limit & Availability Switch) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-zinc-800/80">
                {/* Price Limit Slider */}
                <div>
                  <div className="flex justify-between items-center text-xs font-mono mb-2">
                    <span className="text-zinc-400 uppercase tracking-wider">Max Price Limit:</span>
                    <span className="text-amber-400 font-bold">{priceLimit.toLocaleString()} EGP</span>
                  </div>
                  <input
                    type="range"
                    min={500}
                    max={maxAvailablePrice}
                    step={100}
                    value={priceLimit}
                    onChange={(e) => setPriceLimit(Number(e.target.value))}
                    className="w-full accent-amber-500 h-2 bg-zinc-900 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Stock fast switch & reset advanced */}
                <div className="flex items-center justify-between gap-3 pt-2">
                  <button
                    onClick={() => { setInStockOnly(!inStockOnly); setDisplayLimit(8); }}
                    className={`flex-1 py-3 px-4 rounded-2xl border text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
                      inStockOnly ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400 font-black shadow-lg' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span>In Stock Only</span>
                    {inStockOnly && <Check className="w-4 h-4" />}
                  </button>

                  {isAdvancedFiltered && (
                    <button
                      onClick={handleResetAdvanced}
                      className="p-3 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-all flex items-center justify-center shadow"
                      title="Reset advanced options"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </div>

      {/* Filter Status / Results Count */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-zinc-400 px-2">
        <div className="flex items-center gap-2">
          <span>Displaying <strong className="text-amber-400 font-bold tracking-wider">{visibleProducts.length}</strong> of <strong className="text-white font-bold">{filteredProducts.length}</strong> drops</span>
          {isFiltered && <span className="text-emerald-400 font-bold">&bull; Filter Active</span>}
        </div>

        {isFiltered && (
          <button
            onClick={handleResetAll}
            className="text-red-400 hover:underline flex items-center gap-1 font-bold"
          >
            <X className="w-3.5 h-3.5" />
            <span>Reset All Filters</span>
          </button>
        )}
      </div>

      {/* Results Card Grid organized beautifully */}
      <AnimatePresence mode="wait">
        {visibleProducts.length === 0 ? (
          <motion.div
            key="empty-results"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-zinc-950 border border-zinc-900 rounded-3xl p-16 text-center max-w-xl mx-auto my-12"
          >
            <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mx-auto text-zinc-600 mb-4 border border-zinc-800">
              <Filter className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white">No exact pieces match your tailoring specifications</h3>
            <p className="mt-2 text-zinc-400 text-xs leading-relaxed max-w-sm mx-auto font-sans">
              We could not find garments matching your exact categories and size selections. Tap below to unroll all ready inventory.
            </p>
            <button
              onClick={handleResetAll}
              className="mt-6 bg-amber-500 hover:bg-amber-400 text-black font-black px-8 py-3.5 rounded-full text-xs uppercase tracking-widest transition-all shadow-lg hover:scale-105"
            >
              Show All Elements
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="results-grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {visibleProducts.map((prod) => (
              <motion.div
                layout
                key={prod.id}
                initial={{ opacity: 0, scale: 0.9, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -15 }}
                transition={{ duration: 0.25 }}
              >
                <ProductCard product={prod} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* SHOW MORE drops pagination CTA */}
      {hasMore && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-4 text-center"
        >
          <button
            onClick={() => setDisplayLimit((prev) => prev + 8)}
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black px-12 py-5 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-widest text-sm transition-all shadow-2xl hover:scale-105"
          >
            <Plus className="w-5 h-5 stroke-[3]" />
            <span>Show More Drops ({filteredProducts.length - visibleProducts.length} Remaining)</span>
          </button>

          <button
            onClick={() => setDisplayLimit(filteredProducts.length)}
            className="px-6 py-5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-mono text-xs font-bold transition-all"
          >
            Reveal Entire Set ({filteredProducts.length})
          </button>
        </motion.div>
      )}

    </div>
  );
}
