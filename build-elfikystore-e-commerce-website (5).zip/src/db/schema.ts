import { pgTable, serial, varchar, text, timestamp, integer, boolean, numeric, jsonb } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  password: varchar('password', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }),
  role: varchar('role', { length: 50 }).default('client').notNull(), // 'client' | 'admin'
  address: text('address'),
  city: varchar('city', { length: 100 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const products = pgTable('products', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  slug: varchar('slug', { length: 255 }).notNull().unique(),
  description: text('description').notNull(),
  price: integer('price').notNull(), // in EGP
  originalPrice: integer('original_price'), // in EGP
  category: varchar('category', { length: 100 }).notNull(), // e.g. Hoodies, Jackets, T-Shirts, Trousers, Accessories
  gender: varchar('gender', { length: 50 }).default('Unisex').notNull(), // Men, Women, Unisex
  images: jsonb('images').$type<string[]>().notNull(),
  sizes: jsonb('sizes').$type<string[]>().notNull(), // ['S', 'M', 'L', 'XL', 'XXL']
  colors: jsonb('colors').$type<string[]>().notNull(), // ['Black', 'Navy', 'Olive']
  featured: boolean('featured').default(false).notNull(),
  newArrival: boolean('new_arrival').default(false).notNull(),
  stock: integer('stock').default(10).notNull(),
  rating: numeric('rating', { precision: 3, scale: 1 }).default('4.8').notNull(),
  reviewCount: integer('review_count').default(24).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const videos = pgTable('videos', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  videoUrl: varchar('video_url', { length: 512 }).notNull(),
  thumbnailUrl: varchar('thumbnail_url', { length: 512 }).notNull(),
  category: varchar('category', { length: 100 }).notNull(),
  duration: varchar('duration', { length: 50 }).default('1:30'),
  featured: boolean('featured').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const orders = pgTable('orders', {
  id: serial('id').primaryKey(),
  orderNumber: varchar('order_number', { length: 100 }).notNull().unique(),
  userId: integer('user_id').references(() => users.id),
  customerName: varchar('customer_name', { length: 255 }).notNull(),
  customerEmail: varchar('customer_email', { length: 255 }).notNull(),
  customerPhone: varchar('customer_phone', { length: 100 }).notNull(),
  customerAddress: text('customer_address').notNull(),
  customerCity: varchar('customer_city', { length: 100 }).notNull(),
  paymentMethod: varchar('payment_method', { length: 100 }).notNull(), // 'Vodafone Cash' | 'Etisalat Cash' | 'Orange Cash' | 'We Cash' | 'InstaPay'
  paymentPhoneOrInsta: varchar('payment_phone_or_insta', { length: 255 }).notNull(),
  transactionId: varchar('transaction_id', { length: 255 }).notNull(),
  status: varchar('status', { length: 100 }).default('Pending Verification').notNull(), // Pending Verification | Processing | Shipped | Delivered | Cancelled
  totalAmount: integer('total_amount').notNull(), // in EGP
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const orderItems = pgTable('order_items', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id').references(() => orders.id, { onDelete: 'cascade' }).notNull(),
  productId: integer('product_id').references(() => products.id).notNull(),
  productTitle: varchar('product_title', { length: 255 }).notNull(),
  price: integer('price').notNull(),
  quantity: integer('quantity').notNull(),
  selectedSize: varchar('selected_size', { length: 50 }).notNull(),
  selectedColor: varchar('selected_color', { length: 100 }).notNull(),
  productImage: varchar('product_image', { length: 512 }),
});

export const customerMessages = pgTable('customer_messages', {
  id: serial('id').primaryKey(),
  senderName: varchar('sender_name', { length: 255 }).notNull(),
  senderEmail: varchar('sender_email', { length: 255 }).notNull(),
  senderPhone: varchar('sender_phone', { length: 100 }),
  message: text('message').notNull(),
  status: varchar('status', { length: 50 }).default('Unread').notNull(), // Unread | Read | Replied
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const ordersRelations = relations(orders, ({ many, one }) => ({
  user: one(users, {
    fields: [orders.userId],
    references: [users.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
}));
