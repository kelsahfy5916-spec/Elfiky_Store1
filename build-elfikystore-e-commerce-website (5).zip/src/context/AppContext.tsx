'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface CartItem {
  id: string; // unique ID composed of productId + size + color
  productId: number;
  productTitle: string;
  price: number;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
  productImage: string;
  category: string;
}

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  phone?: string;
  role: string; // 'client' | 'admin'
  address?: string;
  city?: string;
}

interface AppContextType {
  user: AuthUser | null;
  setUser: (user: AuthUser | null) => void;
  cart: CartItem[];
  addToCart: (product: any, size: string, color: string, quantity?: number) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  quickViewProduct: any | null;
  setQuickViewProduct: (prod: any | null) => void;
  isAiChatOpen: boolean;
  setIsAiChatOpen: (open: boolean) => void;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<AuthUser | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<any | null>(null);
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);

  // Load user & cart from localStorage on initialize
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem('elfiky_user');
      if (savedUser) {
        setUserState(JSON.parse(savedUser));
      } else {
        // By default, let's initialize an unauthenticated state, or let them choose
      }

      const savedCart = localStorage.getItem('elfiky_cart');
      if (savedCart) {
        setCart(JSON.parse(savedCart));
      }
    } catch (e) {
      console.error('Failed to load storage', e);
    }
  }, []);

  const setUser = (newUser: AuthUser | null) => {
    setUserState(newUser);
    if (newUser) {
      localStorage.setItem('elfiky_user', JSON.stringify(newUser));
    } else {
      localStorage.removeItem('elfiky_user');
    }
  };

  const logout = () => {
    setUser(null);
  };

  // Save cart to storage on updates
  useEffect(() => {
    try {
      localStorage.setItem('elfiky_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart', e);
    }
  }, [cart]);

  const addToCart = (product: any, size: string, color: string, quantity: number = 1) => {
    const itemId = `${product.id}-${size}-${color}`;
    setCart((prev) => {
      const existingIdx = prev.findIndex(item => item.id === itemId);
      if (existingIdx > -1) {
        const copy = [...prev];
        copy[existingIdx].quantity += quantity;
        return copy;
      } else {
        const newItem: CartItem = {
          id: itemId,
          productId: product.id,
          productTitle: product.title,
          price: product.price,
          selectedSize: size,
          selectedColor: color,
          quantity: quantity,
          productImage: product.images[0] || '',
          category: product.category,
        };
        return [...prev, newItem];
      }
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) => {
      return prev.map(item => {
        if (item.id === id) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotal,
        cartCount,
        isCartOpen,
        setIsCartOpen,
        quickViewProduct,
        setQuickViewProduct,
        isAiChatOpen,
        setIsAiChatOpen,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
